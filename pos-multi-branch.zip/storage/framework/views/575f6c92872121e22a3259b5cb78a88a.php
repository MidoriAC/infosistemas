



<?php if(auth()->check() && isset($sucursalActual)): ?>
<div class="dropdown ms-3">
    <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center"
            type="button"
            id="sucursalDropdown"
            data-bs-toggle="dropdown"
            aria-expanded="false">
        <i class="fas fa-store me-2"></i>
        <div class="text-start">
            <small class="d-block" style="font-size: 0.7rem; opacity: 0.8;">Sucursal:</small>
            <strong style="font-size: 0.9rem;"><?php echo e($sucursalActual->nombre ?? 'Sin sucursal'); ?></strong>
        </div>
    </button>

    <?php if($puedeHacerCambios && isset($sucursalesDisponibles)): ?>
    <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="sucursalDropdown" style="min-width: 280px;">
        <li class="px-3 py-2 bg-light border-bottom">
            <small class="text-muted">Seleccione una sucursal:</small>
        </li>

        <?php $__currentLoopData = $sucursalesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a class="dropdown-item sucursal-option <?php echo e($sucursalActual && $sucursalActual->id == $sucursal->id ? 'active' : ''); ?>"
               href="#"
               data-sucursal-id="<?php echo e($sucursal->id); ?>"
               onclick="event.preventDefault(); cambiarSucursal(<?php echo e($sucursal->id); ?>, '<?php echo e($sucursal->nombre); ?>')">
                <div class="d-flex align-items-center">
                    <div class="me-2">
                        <?php if($sucursalActual && $sucursalActual->id == $sucursal->id): ?>
                        <i class="fas fa-check-circle text-success"></i>
                        <?php else: ?>
                        <i class="fas fa-store text-muted"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="fw-bold"><?php echo e($sucursal->nombre); ?></div>
                        <small class="text-muted"><?php echo e($sucursal->codigo); ?></small>
                    </div>
                </div>
            </a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-sucursal')): ?>
        <li><hr class="dropdown-divider"></li>
        <li>
            <a class="dropdown-item text-primary" href="<?php echo e(route('sucursales.index')); ?>">
                <i class="fas fa-cog me-2"></i> Administrar sucursales
            </a>
        </li>
        <?php endif; ?>
    </ul>
    <?php endif; ?>
</div>

<style>
    .dropdown-item.active {
        background-color: #e7f3ff;
        color: #0d6efd;
    }

    .sucursal-option:hover {
        background-color: #f8f9fa;
    }

    #sucursalDropdown {
        border: 1px solid rgba(255, 255, 255, 0.3);
        padding: 0.5rem 1rem;
    }

    #sucursalDropdown:hover {
        background-color: rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.5);
    }
</style>

<script>
function cambiarSucursal(sucursalId, nombre) {
    // Mostrar loading
    Swal.fire({
        title: 'Cambiando sucursal...',
        text: 'Por favor espere',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    // Hacer petición AJAX
    fetch('<?php echo e(route("sucursal.cambiar")); ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        },
        body: JSON.stringify({
            sucursal_id: sucursalId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Sucursal cambiada',
                text: 'Ahora está trabajando en: ' + nombre,
                timer: 1500,
                showConfirmButton: false
            }).then(() => {
                // Recargar la página para actualizar todos los datos
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message || 'No se pudo cambiar de sucursal'
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Ocurrió un error al cambiar de sucursal'
        });
    });
}
</script>
<?php endif; ?>














<?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/components/sucursal-selector.blade.php ENDPATH**/ ?>