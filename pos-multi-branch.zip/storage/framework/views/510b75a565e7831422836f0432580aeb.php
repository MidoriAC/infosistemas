<?php $__env->startSection('title','Reporte de Ventas'); ?>

<?php $__env->startPush('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .stat-card {
        border-left: 4px solid;
        transition: transform 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-5px);
    }
    .filters-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">
        <i class="fas fa-chart-line"></i> Reporte de Ventas
    </h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('reportes.index')); ?>">Reportes</a></li>
        <li class="breadcrumb-item active">Ventas</li>
    </ol>

    <!-- Filtros -->
    <div class="card filters-card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('reportes.ventas')); ?>" method="GET" id="formFiltros">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label"><i class="fas fa-calendar-alt"></i> Fecha Inicio</label>
                        <input type="date" name="fecha_inicio" class="form-control"
                               value="<?php echo e($fechaInicio); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label"><i class="fas fa-calendar-check"></i> Fecha Fin</label>
                        <input type="date" name="fecha_fin" class="form-control"
                               value="<?php echo e($fechaFin); ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label"><i class="fas fa-store"></i> Sucursal</label>
                        <select name="sucursal_id" class="form-select">
                            <option value="todas" <?php echo e($sucursalFiltro == 'todas' ? 'selected' : ''); ?>>Todas</option>
                            <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sucursal->id); ?>" <?php echo e($sucursalFiltro == $sucursal->id ? 'selected' : ''); ?>>
                                <?php echo e($sucursal->nombre); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label"><i class="fas fa-file-invoice"></i> Tipo</label>
                        <select name="tipo_factura" class="form-select">
                            <option value="TODOS" <?php echo e($tipoFactura == 'TODOS' ? 'selected' : ''); ?>>Todos</option>
                            <option value="FACT" <?php echo e($tipoFactura == 'FACT' ? 'selected' : ''); ?>>FEL</option>
                            <option value="RECI" <?php echo e($tipoFactura == 'RECI' ? 'selected' : ''); ?>>Recibo</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-light w-100">
                            <i class="fas fa-search"></i> Generar
                        </button>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-2">
                        <label class="form-label"><i class="fas fa-toggle-on"></i> Estado</label>
                        <select name="estado" class="form-select">
                            <option value="todos" <?php echo e($estado == 'todos' ? 'selected' : ''); ?>>Todos</option>
                            <option value="activos" <?php echo e($estado == 'activos' ? 'selected' : ''); ?>>Activos</option>
                            <option value="anulados" <?php echo e($estado == 'anulados' ? 'selected' : ''); ?>>Anulados</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('reportes.ventas.pdf', request()->query())); ?>"
                           class="btn btn-danger w-100" target="_blank">
                            <i class="fas fa-file-pdf"></i> Exportar PDF
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Estadísticas -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card" style="border-left-color: #667eea;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Total Ventas</div>
                            <div class="h4 mb-0"><?php echo e($estadisticas['total_ventas']); ?></div>
                        </div>
                        <i class="fas fa-shopping-cart fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card" style="border-left-color: #28a745;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Monto Total</div>
                            <div class="h4 mb-0">Q <?php echo e(number_format($estadisticas['total_monto'], 2)); ?></div>
                        </div>
                        <i class="fas fa-dollar-sign fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card" style="border-left-color: #ffc107;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Promedio Venta</div>
                            <div class="h4 mb-0">Q <?php echo e(number_format($estadisticas['promedio_venta'], 2)); ?></div>
                        </div>
                        <i class="fas fa-chart-line fa-2x text-warning"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card" style="border-left-color: #17a2b8;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Productos Vendidos</div>
                            <div class="h4 mb-0"><?php echo e($estadisticas['productos_vendidos']); ?></div>
                        </div>
                        <i class="fas fa-boxes fa-2x text-info"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-chart-pie"></i> Ventas por Tipo
                </div>
                <div class="card-body">
                    <canvas id="chartTipos"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-chart-bar"></i> Top 5 Vendedores
                </div>
                <div class="card-body">
                    <canvas id="chartVendedores"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Detalle por Día -->
    <div class="card mb-4">
        <div class="card-header bg-info text-white">
            <i class="fas fa-calendar-alt"></i> Ventas por Día
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th class="text-center">Cantidad Ventas</th>
                            <th class="text-end">Monto Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $ventasPorDia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong><?php echo e($dia['fecha']); ?></strong></td>
                            <td class="text-center">
                                <span class="badge bg-primary"><?php echo e($dia['cantidad']); ?></span>
                            </td>
                            <td class="text-end"><strong>Q <?php echo e(number_format($dia['monto'], 2)); ?></strong></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="text-center text-muted">No hay ventas en el período seleccionado</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="table-dark">
                        <tr>
                            <th>TOTAL</th>
                            <th class="text-center"><?php echo e($estadisticas['total_ventas']); ?></th>
                            <th class="text-end">Q <?php echo e(number_format($estadisticas['total_monto'], 2)); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <!-- Listado Detallado -->
    <div class="card">
        <div class="card-header bg-dark text-white">
            <i class="fas fa-list"></i> Detalle de Ventas
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-sm">
                    <thead class="table-light">
                        <tr>
                            <th>N° Comprobante</th>
                            <th>Fecha</th>
                            <th>Cliente</th>
                            <th>Tipo</th>
                            <th>Sucursal</th>
                            <th class="text-end">Total</th>
                            <th>Vendedor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong><?php echo e($venta->numero_comprobante); ?></strong></td>
                            <td><?php echo e($venta->fecha_hora->format('d/m/Y H:i')); ?></td>
                            <td><?php echo e($venta->cliente->persona->razon_social); ?></td>
                            <td>
                                <?php if($venta->tipo_factura === 'FACT'): ?>
                                <span class="badge bg-success">FEL</span>
                                <?php else: ?>
                                <span class="badge bg-secondary">Recibo</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($venta->sucursal->nombre); ?></td>
                            <td class="text-end"><strong>Q <?php echo e(number_format($venta->total, 2)); ?></strong></td>
                            <td><?php echo e($venta->user->name); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">No hay ventas en el período seleccionado</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
// Gráfico de Tipos
const ctxTipos = document.getElementById('chartTipos').getContext('2d');
new Chart(ctxTipos, {
    type: 'doughnut',
    data: {
        labels: ['FEL', 'Recibo'],
        datasets: [{
            data: [<?php echo e($estadisticas['ventas_fel']); ?>, <?php echo e($estadisticas['ventas_recibo']); ?>],
            backgroundColor: ['#28a745', '#6c757d']
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// Gráfico de Vendedores
const ctxVendedores = document.getElementById('chartVendedores').getContext('2d');
new Chart(ctxVendedores, {
    type: 'bar',
    data: {
        labels: [
            <?php $__currentLoopData = $topVendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($vendedor["vendedor"]); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Monto (Q)',
            data: [
                <?php $__currentLoopData = $topVendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($vendedor['monto']); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: '#667eea'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/reportes/ventas.blade.php ENDPATH**/ ?>