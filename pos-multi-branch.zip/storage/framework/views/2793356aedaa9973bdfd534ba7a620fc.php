<?php $__env->startSection('title','Productos Dañados'); ?>

<?php $__env->startPush('css-datatable'); ?>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .badge-motivo {
        font-size: 0.75rem;
        padding: 0.35em 0.65em;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Control de Productos Dañados</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Productos Dañados</li>
    </ol>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('registrar-producto-danado')): ?>
    <div class="mb-4">
        <a href="<?php echo e(route('productos-danados.create')); ?>">
            <button type="button" class="btn btn-danger">
                <i class="fas fa-exclamation-triangle"></i> Reportar Producto Dañado
            </button>
        </a>
    </div>
    <?php endif; ?>

    <!-- Tarjetas de resumen -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Pendientes</div>
                            <div class="h5 mb-0">
                                <?php echo e($productosDanados->where('estado', 'PENDIENTE')->count()); ?>

                            </div>
                        </div>
                        <i class="fas fa-clock fa-2x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Aprobados</div>
                            <div class="h5 mb-0">
                                <?php echo e($productosDanados->where('estado', 'APROBADO')->count()); ?>

                            </div>
                        </div>
                        <i class="fas fa-check-circle fa-2x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Rechazados</div>
                            <div class="h5 mb-0">
                                <?php echo e($productosDanados->where('estado', 'RECHAZADO')->count()); ?>

                            </div>
                        </div>
                        <i class="fas fa-times-circle fa-2x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Pérdida Total</div>
                            <div class="h5 mb-0">
                                Q <?php echo e(number_format($productosDanados->where('estado', 'aprobado')->sum('costo_perdida'), 2)); ?>

                            </div>
                        </div>
                        <i class="fas fa-dollar-sign fa-2x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-exclamation-triangle me-1"></i>
            Tabla de Productos Dañados
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped fs-6">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Producto</th>
                        <th>Sucursal</th>
                        <th>Cantidad</th>
                        <th>Motivo</th>
                        <th>Costo Pérdida</th>
                        <th>Estado</th>
                        <th>Reportado Por</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productosDanados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <small><?php echo e($item->fecha_registro->format('d/m/Y H:i')); ?></small>
                        </td>
                        <td>
                            <strong><?php echo e($item->producto->nombre); ?></strong><br>
                            <small class="text-muted">Código: <?php echo e($item->producto->codigo); ?></small>
                        </td>
                        <td>
                            <span class="badge bg-info"><?php echo e($item->sucursal->nombre); ?></span>
                        </td>
                        <td>
                            <span class="badge bg-danger"><?php echo e($item->cantidad); ?></span>
                        </td>
                        <td>
                            <?php
                                $motivoBadge = match($item->motivo) {
                                    'vencido' => 'bg-warning',
                                    'roto' => 'bg-danger',
                                    'deteriorado' => 'bg-secondary',
                                    'humedad' => 'bg-primary',
                                    'contaminacion' => 'bg-dark',
                                    'defecto_fabrica' => 'bg-info',
                                    'otro' => 'bg-light text-dark',
                                    default => 'bg-secondary'
                                };
                                $motivoTexto = match($item->motivo) {
                                    'vencido' => 'Vencido',
                                    'roto' => 'Roto',
                                    'deteriorado' => 'Deteriorado',
                                    'humedad' => 'Humedad',
                                    'contaminacion' => 'Contaminación',
                                    'defecto_fabrica' => 'Defecto de Fábrica',
                                    'otro' => 'Otro',
                                    default => $item->motivo
                                };
                            ?>
                            <span class="badge <?php echo e($motivoBadge); ?> badge-motivo">
                                <?php echo e($motivoTexto); ?>

                            </span>
                        </td>
                        <td>
                            <strong>Q <?php echo e(number_format($item->costo_perdida, 2)); ?></strong>
                        </td>
                        <td>
                            <?php if($item->estado == 'PENDIENTE'): ?>
                                <span class="badge bg-warning">
                                    <i class="fas fa-clock"></i> Pendiente
                                </span>
                            <?php elseif($item->estado == 'APROBADO'): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-check"></i> Aprobado
                                </span>
                            <?php else: ?>
                                <span class="badge bg-danger">
                                    <i class="fas fa-times"></i> Rechazado
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <small><?php echo e($item->usuario->name); ?></small>
                        </td>
                        <td>
                            <div class="d-flex justify-content-around">
                                <div>
                                    <button title="Opciones" class="btn btn-datatable btn-icon btn-transparent-dark me-2" data-bs-toggle="dropdown" aria-expanded="false">
                                        <svg class="svg-inline--fa fa-ellipsis-vertical" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis-vertical" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512">
                                            <path fill="currentColor" d="M56 472a56 56 0 1 1 0-112 56 56 0 1 1 0 112zm0-160a56 56 0 1 1 0-112 56 56 0 1 1 0 112zM0 96a56 56 0 1 1 112 0A56 56 0 1 1 0 96z"></path>
                                        </svg>
                                    </button>
                                    <ul class="dropdown-menu text-bg-light" style="font-size: small;">
                                        <!-----Ver Detalles--->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-producto-danado')): ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('productos-danados.show', $item->id)); ?>">
                                                <i class="fas fa-eye"></i> Ver Detalles
                                            </a>
                                        </li>
                                        <?php endif; ?>

                                        <?php if($item->estado == 'pendiente'): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('aprobar-producto-danado')): ?>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <button class="dropdown-item text-success" data-bs-toggle="modal" data-bs-target="#aprobarModal-<?php echo e($item->id); ?>">
                                                    <i class="fas fa-check"></i> Aprobar
                                                </button>
                                            </li>
                                            <li>
                                                <button class="dropdown-item text-danger" data-bs-toggle="modal" data-bs-target="#rechazarModal-<?php echo e($item->id); ?>">
                                                    <i class="fas fa-times"></i> Rechazar
                                                </button>
                                            </li>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </td>
                    </tr>

                    <!-- Modal Aprobar -->
                    <div class="modal fade" id="aprobarModal-<?php echo e($item->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-success text-white">
                                    <h5 class="modal-title">Aprobar Reporte</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>¿Está seguro de aprobar este reporte?</p>
                                    <div class="alert alert-warning">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        <strong>Advertencia:</strong> Al aprobar, se descontarán <strong><?php echo e($item->cantidad); ?> unidades</strong> del inventario de la sucursal <strong><?php echo e($item->sucursal->nombre); ?></strong>.
                                    </div>
                                    <ul>
                                        <li><strong>Producto:</strong> <?php echo e($item->producto->nombre); ?></li>
                                        <li><strong>Cantidad:</strong> <?php echo e($item->cantidad); ?></li>
                                        <li><strong>Costo de pérdida:</strong> Q <?php echo e(number_format($item->costo_perdida, 2)); ?></li>
                                    </ul>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <form action="<?php echo e(route('productos-danados.aprobar', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success">Aprobar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Rechazar -->
                    <div class="modal fade" id="rechazarModal-<?php echo e($item->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-danger text-white">
                                    <h5 class="modal-title">Rechazar Reporte</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>¿Está seguro de rechazar este reporte?</p>
                                    <p><strong>Producto:</strong> <?php echo e($item->producto->nombre); ?></p>
                                    <p><strong>Reportado por:</strong> <?php echo e($item->usuario->name); ?></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <form action="<?php echo e(route('productos-danados.rechazar', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Rechazar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" type="text/javascript"></script>
<script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/producto-danado/index.blade.php ENDPATH**/ ?>