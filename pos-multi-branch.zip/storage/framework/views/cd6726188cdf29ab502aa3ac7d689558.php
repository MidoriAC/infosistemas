<?php $__env->startSection('title','Cotizaciones'); ?>

<?php $__env->startPush('css-datatable'); ?>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .card-stats {
        transition: transform 0.3s;
    }
    .card-stats:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    .badge-estado {
        font-size: 0.75rem;
        padding: 0.4em 0.8em;
    }
    .vencimiento-pronto {
        color: #dc3545;
        font-weight: bold;
    }
    .vencimiento-normal {
        color: #28a745;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">
        <i class="fas fa-file-invoice"></i> Gestión de Cotizaciones
    </h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Cotizaciones</li>
    </ol>

    
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card card-stats bg-primary text-white mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-white-50 mb-0">Total Cotizaciones</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($estadisticas['total_cotizaciones']); ?></span>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-file-invoice fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card card-stats bg-warning text-white mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-white-50 mb-0">Pendientes</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($estadisticas['pendientes']); ?></span>
                            <p class="mb-0 text-sm">Q <?php echo e(number_format($estadisticas['monto_pendiente'], 2)); ?></p>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card card-stats bg-success text-white mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-white-50 mb-0">Convertidas</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($estadisticas['convertidas']); ?></span>
                            <p class="mb-0 text-sm">Q <?php echo e(number_format($estadisticas['monto_convertido'], 2)); ?></p>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card card-stats bg-danger text-white mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-white-50 mb-0">Vencidas</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($estadisticas['vencidas']); ?></span>
                            <p class="mb-0 text-sm">Canceladas: <?php echo e($estadisticas['canceladas']); ?></p>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-times-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-cotizacion')): ?>
    <div class="mb-4">
        <a href="<?php echo e(route('cotizaciones.create')); ?>">
            <button type="button" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nueva Cotización
            </button>
        </a>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Listado de Cotizaciones
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped fs-6">
                <thead>
                    <tr>
                        <th>N° Cotización</th>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Sucursal</th>
                        <th>Total</th>
                        <th>Validez</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cotizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <strong><?php echo e($cotizacion->numero_cotizacion); ?></strong>
                        </td>
                        <td>
                            <?php echo e($cotizacion->fecha_hora->format('d/m/Y')); ?><br>
                            <small class="text-muted"><?php echo e($cotizacion->fecha_hora->format('H:i')); ?></small>
                        </td>
                        <td>
                            <strong><?php echo e($cotizacion->cliente->persona->razon_social); ?></strong><br>
                            <small class="text-muted"><?php echo e($cotizacion->cliente->persona->numero_documento); ?></small>
                        </td>
                        <td><?php echo e($cotizacion->sucursal->nombre); ?></td>
                        <td class="text-end">
                            <strong>Q <?php echo e(number_format($cotizacion->total, 2)); ?></strong>
                        </td>
                        <td>
                            <span class="<?php echo e($cotizacion->diasRestantes() <= 3 && $cotizacion->estado === 'PENDIENTE' ? 'vencimiento-pronto' : 'vencimiento-normal'); ?>">
                                <?php if($cotizacion->estado === 'PENDIENTE'): ?>
                                    <?php if($cotizacion->diasRestantes() > 0): ?>
                                        <?php echo e($cotizacion->diasRestantes()); ?> días restantes
                                    <?php else: ?>
                                        Vencida
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo e($cotizacion->fecha_vencimiento->format('d/m/Y')); ?>

                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <?php echo $cotizacion->obtenerEstadoBadge(); ?>

                            <?php if($cotizacion->venta): ?>
                                <br><small class="text-muted">
                                    Venta: <?php echo e($cotizacion->venta->numero_comprobante); ?>

                                </small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex justify-content-around">
                                <div class="btn-group" role="group">
                                    <button title="Opciones" class="btn btn-datatable btn-icon btn-transparent-dark dropdown-toggle"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-ellipsis-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu text-bg-light">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-cotizacion')): ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('cotizaciones.show', $cotizacion->id)); ?>">
                                                <i class="fas fa-eye"></i> Ver Detalle
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('cotizaciones.pdf', $cotizacion->id)); ?>" target="_blank">
                                                <i class="fas fa-file-pdf"></i> Generar PDF
                                            </a>
                                        </li>
                                        <?php endif; ?>

                                        <li><hr class="dropdown-divider"></li>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-cotizacion')): ?>
                                        <?php if($cotizacion->puedeEditarse()): ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('cotizaciones.edit', $cotizacion->id)); ?>">
                                                <i class="fas fa-edit"></i> Editar
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('convertir-cotizacion')): ?>
                                        <?php if($cotizacion->puedeConvertirse()): ?>
                                        <li>
                                            <a class="dropdown-item text-success" href="<?php echo e(route('cotizaciones.convertir', $cotizacion->id)); ?>">
                                                <i class="fas fa-exchange-alt"></i> Convertir a Venta
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php endif; ?>

                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('cotizaciones.duplicar', $cotizacion->id)); ?>">
                                                <i class="fas fa-copy"></i> Duplicar
                                            </a>
                                        </li>

                                        <li><hr class="dropdown-divider"></li>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar-cotizacion')): ?>
                                        <?php if($cotizacion->puedeCancelarse()): ?>
                                        <li>
                                            <a class="dropdown-item text-danger" href="<?php echo e(route('cotizaciones.cancelar', $cotizacion->id)); ?>">
                                                <i class="fas fa-ban"></i> Cancelar Cotización
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" type="text/javascript"></script>
<script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/cotizacion/index.blade.php ENDPATH**/ ?>