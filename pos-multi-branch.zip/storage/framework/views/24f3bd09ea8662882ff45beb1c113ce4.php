<?php $__env->startSection('title','Productos'); ?>

<?php $__env->startPush('css-datatable'); ?>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .badge-categoria {
        font-size: 0.7rem;
        margin: 2px;
    }
    .cantidad-input {
        width: 80px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Productos</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Productos</li>
    </ol>

    <div class="mb-4 d-flex justify-content-between">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-producto')): ?>
        <div>
            <a href="<?php echo e(route('productos.create')); ?>">
                <button type="button" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Añadir Nuevo Producto
                </button>
            </a>
        </div>
        <?php endif; ?>

        
    </div>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-box me-1"></i>
            Tabla de Productos
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped fs-6">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Presentación</th>
                        <th>Unidad</th>
                        <th>Categorías</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <strong><?php echo e($item->codigo); ?></strong>
                        </td>
                        <td>
                            <?php echo e($item->nombre); ?>

                        </td>
                        <td>
                            <span class="badge bg-primary">
                                <?php echo e($item->marca->caracteristica->nombre); ?>

                            </span>
                        </td>
                        <td>
                            <span class="badge bg-info">
                                <?php echo e($item->presentacione->caracteristica->nombre); ?>

                            </span>
                        </td>
                        <td>
                            <?php if($item->unidadMedida): ?>
                                <span class="badge bg-secondary">
                                    <?php echo e($item->unidadMedida->abreviatura); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php $__currentLoopData = $item->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge rounded-pill bg-secondary badge-categoria">
                                <?php echo e($category->caracteristica->nombre); ?>

                            </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php if($item->estado == 1): ?>
                            <span class="badge bg-success">Activo</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Eliminado</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex justify-content-around">
                                <div>
                                    <button title="Opciones" class="btn btn-datatable btn-icon btn-transparent-dark me-2" data-bs-toggle="dropdown" aria-expanded="false">
                                        <svg class="svg-inline--fa fa-ellipsis-vertical" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis-vertical" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512">
                                            <path fill="currentColor" d="M56 472a56 56 0 1 1 0-112 56 56 0 1 1 0 112zm0-160a56 56 0 1 1 0-112 56 56 0 1 1 0 112zM0 96a56 56 0 1 1 112 0A56 56 0 1 1 0 96z"></path>
                                        </svg>
                                    </button>
                                    <ul class="dropdown-menu text-bg-light" style="font-size: small;">
                                        <!-----Ver Producto--->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-producto')): ?>
                                        <li>
                                            <a class="dropdown-item" role="button" data-bs-toggle="modal" data-bs-target="#verModal-<?php echo e($item->id); ?>">
                                                <i class="fas fa-eye"></i> Ver Detalles
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <!-----Editar Producto--->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-producto')): ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('productos.edit',['producto' => $item])); ?>">
                                                <i class="fas fa-edit"></i> Editar
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <!-----Código de Barras--->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-producto')): ?>
                                        <li>
                                            <a class="dropdown-item" role="button" data-bs-toggle="modal" data-bs-target="#codigoBarrasModal-<?php echo e($item->id); ?>">
                                                <i class="fas fa-barcode"></i> Imprimir Código de Barras
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div>
                                    <div class="vr"></div>
                                </div>
                                <div>
                                    <!------Eliminar/Restaurar producto---->
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar-producto')): ?>
                                    <?php if($item->estado == 1): ?>
                                    <button title="Eliminar" data-bs-toggle="modal" data-bs-target="#confirmModal-<?php echo e($item->id); ?>" class="btn btn-datatable btn-icon btn-transparent-dark">
                                        <svg class="svg-inline--fa fa-trash-can" aria-hidden="true" focusable="false" data-prefix="far" data-icon="trash-can" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                            <path fill="currentColor" d="M170.5 51.6L151.5 80h145l-19-28.4c-1.5-2.2-4-3.6-6.7-3.6H177.1c-2.7 0-5.2 1.3-6.7 3.6zm147-26.6L354.2 80H368h48 8c13.3 0 24 10.7 24 24s-10.7 24-24 24h-8V432c0 44.2-35.8 80-80 80H112c-44.2 0-80-35.8-80-80V128H24c-13.3 0-24-10.7-24-24S10.7 80 24 80h8H80 93.8l36.7-55.1C140.9 9.4 158.4 0 177.1 0h93.7c18.7 0 36.2 9.4 46.6 24.9zM80 128V432c0 17.7 14.3 32 32 32H336c17.7 0 32-14.3 32-32V128H80zm80 64V400c0 8.8-7.2 16-16 16s-16-7.2-16-16V192c0-8.8 7.2-16 16-16s16 7.2 16 16zm80 0V400c0 8.8-7.2 16-16 16s-16-7.2-16-16V192c0-8.8 7.2-16 16-16s16 7.2 16 16zm80 0V400c0 8.8-7.2 16-16 16s-16-7.2-16-16V192c0-8.8 7.2-16 16-16s16 7.2 16 16z"></path>
                                        </svg>
                                    </button>
                                    <?php else: ?>
                                    <button title="Restaurar" data-bs-toggle="modal" data-bs-target="#confirmModal-<?php echo e($item->id); ?>" class="btn btn-datatable btn-icon btn-transparent-dark">
                                        <i class="fa-solid fa-rotate"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>

                    <!-- Modal Código de Barras -->
                    
                    <div class="modal fade" id="codigoBarrasModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="codigoBarrasLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-info text-white">
                                    <h5 class="modal-title" id="codigoBarrasLabel">
                                        <i class="fas fa-barcode"></i> Imprimir Códigos de Barras
                                    </h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('productos.codigo-barras', $item->id)); ?>" method="GET" target="_blank">
                                    <div class="modal-body">
                                        <div class="text-center mb-3">
                                            <strong><?php echo e($item->nombre); ?></strong><br>
                                            <small class="text-muted">Código: <?php echo e($item->codigo); ?></small>
                                        </div>

                                        <div class="row">
                                            <div class="col-12 mb-3">
                                                <label for="cantidad-<?php echo e($item->id); ?>" class="form-label">
                                                    <i class="fas fa-copy"></i> Cantidad de etiquetas a imprimir:
                                                </label>
                                                <input type="number"
                                                       class="form-control"
                                                       id="cantidad-<?php echo e($item->id); ?>"
                                                       name="cantidad"
                                                       value="10"
                                                       min="1"
                                                       max="100"
                                                       required>
                                                <small class="form-text text-muted">
                                                    Máximo 100 etiquetas por impresión
                                                </small>
                                            </div>
                                        </div>

                                        
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                            <i class="fas fa-times"></i> Cancelar
                                        </button>
                                        <button type="submit" class="btn btn-info">
                                            <i class="fas fa-print"></i> Generar PDF
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Ver Detalles -->
                    <div class="modal fade" id="verModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                            <div class="modal-content">
                                <div class="modal-header bg-primary text-white">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                                        <i class="fas fa-box"></i> Detalles del Producto
                                    </h1>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <p><span class="fw-bolder">Código:</span> <?php echo e($item->codigo); ?></p>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <p><span class="fw-bolder">Nombre:</span> <?php echo e($item->nombre); ?></p>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <p><span class="fw-bolder">Marca:</span> <?php echo e($item->marca->caracteristica->nombre); ?></p>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <p><span class="fw-bolder">Presentación:</span> <?php echo e($item->presentacione->caracteristica->nombre); ?></p>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <p><span class="fw-bolder">Unidad de Medida:</span>
                                                <?php if($item->unidadMedida): ?>
                                                    <?php echo e($item->unidadMedida->nombre); ?> (<?php echo e($item->unidadMedida->abreviatura); ?>)
                                                <?php else: ?>
                                                    No especificada
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <p><span class="fw-bolder">Fecha de vencimiento:</span>
                                                <?php echo e($item->fecha_vencimiento ? $item->fecha_vencimiento->format('d/m/Y') : 'No tiene'); ?>

                                            </p>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <p><span class="fw-bolder">Descripción:</span>
                                                <?php echo e($item->descripcion ?? 'Sin descripción'); ?>

                                            </p>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <p><span class="fw-bolder">Categorías:</span></p>
                                            <?php $__currentLoopData = $item->categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-secondary me-1"><?php echo e($category->caracteristica->nombre); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="col-12">
                                            <p class="fw-bolder">Imagen:</p>
                                            <div class="text-center">
                                                <?php if($item->img_path != null): ?>
                                                <img src="<?php echo e(Storage::url('public/productos/'.$item->img_path)); ?>"
                                                     alt="<?php echo e($item->nombre); ?>"
                                                     class="img-fluid img-thumbnail border border-4 rounded"
                                                     style="max-height: 400px;">
                                                <?php else: ?>
                                                <div class="alert alert-info">
                                                    <i class="fas fa-image"></i> Este producto no tiene imagen
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                        <i class="fas fa-times"></i> Cerrar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal de confirmación-->
                    <div class="modal fade" id="confirmModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Mensaje de confirmación</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <?php echo e($item->estado == 1 ? '¿Seguro que quieres eliminar el producto?' : '¿Seguro que quieres restaurar el producto?'); ?>

                                    <br><strong><?php echo e($item->nombre); ?></strong>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                    <form action="<?php echo e(route('productos.destroy',['producto'=>$item->id])); ?>" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Confirmar</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" type="text/javascript"></script>
<script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Botones de cantidad rápida
    document.querySelectorAll('.btn-cantidad').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const valor = this.getAttribute('data-valor');
            const input = document.getElementById(targetId);

            if (input) {
                input.value = valor;
                // Disparar evento para actualizar preview
                input.dispatchEvent(new Event('input'));
            }
        });
    });

    // Calcular hojas necesarias en tiempo real
    document.querySelectorAll('input[name="cantidad"]').forEach(function(input) {
        input.addEventListener('input', function() {
            const cantidad = parseInt(this.value) || 0;
            const hojasPorPagina = 8; // 8 etiquetas por hoja
            const hojas = Math.ceil(cantidad / hojasPorPagina);

            // Buscar el elemento de preview correspondiente
            const productId = this.id.split('-')[1];
            const previewElement = document.getElementById('hojas-preview-' + productId);

            if (previewElement) {
                previewElement.textContent = hojas;
            }
        });

        // Inicializar el preview al cargar
        input.dispatchEvent(new Event('input'));
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/producto/index.blade.php ENDPATH**/ ?>