<?php $__env->startSection('title','Sucursales'); ?>

<?php $__env->startPush('css-datatable'); ?>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .badge-activo {
        background-color: #28a745;
    }
    .badge-inactivo {
        background-color: #dc3545;
    }
    .card-sucursal {
        transition: transform 0.2s;
    }
    .card-sucursal:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    .btn-group-sm > .btn {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    .sucursal-actual {
        background-color: #e7f3ff !important;
        border-left: 4px solid #0d6efd;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Gestión de Sucursales</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Sucursales</li>
    </ol>

    
    <?php if(isset($sucursalActual)): ?>
    <div class="alert alert-info d-flex align-items-center mb-4" role="alert">
        <i class="fas fa-info-circle me-3 fs-4"></i>
        <div>
            <strong>Sucursal actual de trabajo:</strong> <?php echo e($sucursalActual->nombre); ?>

            <span class="badge bg-primary ms-2"><?php echo e($sucursalActual->codigo); ?></span>
        </div>
    </div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-md-6">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-sucursal')): ?>
            <a href="<?php echo e(route('sucursales.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Añadir nueva sucursal
            </a>
            <?php endif; ?>
        </div>
        <div class="col-md-6 text-end">
            
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-store me-1"></i>
            Tabla de sucursales activas
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Dirección</th>
                        <th>Contacto</th>
                        <th>Usuarios</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e(isset($sucursalActual) && $sucursalActual->id == $item->id ? 'sucursal-actual' : ''); ?>">
                        <td>
                            <span class="badge bg-primary"><?php echo e($item->codigo); ?></span>
                            <?php if(isset($sucursalActual) && $sucursalActual->id == $item->id): ?>
                            <span class="badge bg-success ms-1">
                                <i class="fas fa-check"></i> Actual
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <p class="fw-semibold mb-1"><?php echo e($item->nombre); ?></p>
                            <?php if($item->codigo_establecimiento): ?>
                            <p class="text-muted mb-0 small">
                                <i class="fas fa-building"></i> Est: <?php echo e($item->codigo_establecimiento); ?>

                            </p>
                            <?php endif; ?>
                        </td>
                        <td>
                            <p class="mb-0"><?php echo e($item->direccion); ?></p>
                        </td>
                        <td>
                            <?php if($item->telefono): ?>
                            <p class="mb-1 small">
                                <i class="fas fa-phone text-primary"></i> <?php echo e($item->telefono); ?>

                            </p>
                            <?php endif; ?>
                            <?php if($item->email): ?>
                            <p class="mb-0 small text-muted">
                                <i class="fas fa-envelope"></i> <?php echo e($item->email); ?>

                            </p>
                            <?php endif; ?>
                            <?php if(!$item->telefono && !$item->email): ?>
                            <span class="text-muted small">Sin contacto</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-info">
                                <?php echo e($item->users->count()); ?>

                                <i class="fas fa-users"></i>
                            </span>
                        </td>
                        <td class="text-center">
                            <?php if($item->estado == 1): ?>
                            <span class="badge badge-activo">
                                <i class="fas fa-check-circle"></i> Activa
                            </span>
                            <?php else: ?>
                            <span class="badge badge-inactivo">
                                <i class="fas fa-times-circle"></i> Inactiva
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm" role="group">

                                
                                <?php if(isset($sucursalActual) && $sucursalActual->id != $item->id && $puedeHacerCambios): ?>
                                <button type="button"
                                        class="btn btn-info"
                                        onclick="cambiarSucursalDesdeTabla(<?php echo e($item->id); ?>, '<?php echo e($item->nombre); ?>')"
                                        title="Cambiar a esta sucursal">
                                    <i class="fas fa-exchange-alt"></i>
                                </button>
                                <?php endif; ?>

                                
                                

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-sucursal')): ?>
                                <a href="<?php echo e(route('sucursales.edit', ['sucursal'=>$item])); ?>"
                                   class="btn btn-warning"
                                   title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php endif; ?>

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar-sucursal')): ?>
                                <button type="button"
                                        class="btn btn-danger"
                                        data-bs-toggle="modal"
                                        data-bs-target="#confirmModal-<?php echo e($item->id); ?>"
                                        title="Desactivar">
                                    <i class="fas fa-ban"></i>
                                </button>
                                <?php endif; ?>

                            </div>
                        </td>
                    </tr>

                    <!-- Modal de confirmación-->
                    <div class="modal fade" id="confirmModal-<?php echo e($item->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-warning">
                                    <h1 class="modal-title fs-5">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        Confirmar desactivación
                                    </h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="alert alert-warning" role="alert">
                                        <strong>¿Está seguro que desea desactivar la sucursal?</strong>
                                    </div>

                                    <div class="mb-3">
                                        <strong>Sucursal:</strong> <?php echo e($item->nombre); ?><br>
                                        <strong>Código:</strong> <?php echo e($item->codigo); ?>

                                    </div>

                                    <?php if($item->tieneMovimientos()): ?>
                                    <div class="alert alert-info" role="alert">
                                        <i class="fas fa-info-circle"></i>
                                        <strong>Información:</strong> Esta sucursal tiene movimientos registrados.
                                        Se desactivará pero no se eliminará permanentemente.
                                        <ul class="mt-2 mb-0">
                                            <li>Ventas: <?php echo e($item->ventas()->count()); ?></li>
                                            <li>Compras: <?php echo e($item->compras()->count()); ?></li>
                                        </ul>
                                    </div>
                                    <?php else: ?>
                                    <div class="alert alert-success" role="alert">
                                        <i class="fas fa-check-circle"></i>
                                        Esta sucursal no tiene movimientos y puede ser eliminada.
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                        <i class="fas fa-times"></i> Cancelar
                                    </button>
                                    <form action="<?php echo e(route('sucursales.destroy',['sucursal'=>$item->id])); ?>" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">
                                            <i class="fas fa-ban"></i> Confirmar desactivación
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" type="text/javascript"></script>
<script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>

<script>
// Función para cambiar sucursal desde la tabla
function cambiarSucursalDesdeTabla(sucursalId, nombre) {
    Swal.fire({
        title: '¿Cambiar de sucursal?',
        html: `¿Desea cambiar a la sucursal: <strong>${nombre}</strong>?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, cambiar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            cambiarSucursal(sucursalId, nombre);
        }
    });
}

// Función para cambiar sucursal (compartida con el selector del header)
function cambiarSucursal(sucursalId, nombre) {
    Swal.fire({
        title: 'Cambiando sucursal...',
        text: 'Por favor espere',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch('<?php echo e(route("sucursal.cambiar")); ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        },
        body: JSON.stringify({
            sucursal_id: sucursalId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: '¡Sucursal cambiada!',
                text: 'Ahora está trabajando en: ' + nombre,
                timer: 1500,
                showConfirmButton: false
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message || 'No se pudo cambiar de sucursal'
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Ocurrió un error al cambiar de sucursal'
        });
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/sucursal/index.blade.php ENDPATH**/ ?>