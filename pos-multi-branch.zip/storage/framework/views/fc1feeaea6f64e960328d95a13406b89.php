<?php $__env->startSection('title','Compras'); ?>

<?php $__env->startPush('css-datatable'); ?>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .stat-card {
        transition: transform 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Compras</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Compras</li>
    </ol>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-compra')): ?>
    <div class="mb-4">
        <a href="<?php echo e(route('compras.create')); ?>">
            <button type="button" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nueva Compra
            </button>
        </a>
    </div>
    <?php endif; ?>

    <!-- Tarjetas de Estadísticas -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Total Compras</div>
                            <div class="h2 mb-0"><?php echo e($estadisticas['total_compras']); ?></div>
                        </div>
                        <i class="fas fa-shopping-cart fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Monto Total</div>
                            <div class="h2 mb-0">Q <?php echo e(number_format($estadisticas['monto_total'], 2)); ?></div>
                        </div>
                        <i class="fas fa-dollar-sign fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Compras Hoy</div>
                            <div class="h2 mb-0"><?php echo e($estadisticas['compras_hoy']); ?></div>
                        </div>
                        <i class="fas fa-calendar-day fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Monto Hoy</div>
                            <div class="h2 mb-0">Q <?php echo e(number_format($estadisticas['monto_hoy'], 2)); ?></div>
                        </div>
                        <i class="fas fa-cash-register fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabla de Compras -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Listado de Compras
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Comprobante</th>
                        <th>Proveedor</th>
                        <th>Sucursal</th>
                        <th>Fecha y Hora</th>
                        <th>Total</th>
                        <th>Usuario</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <p class="fw-semibold mb-1"><?php echo e($item->comprobante->tipo_comprobante); ?></p>
                            <p class="text-muted mb-0">
                                <i class="fas fa-hashtag"></i> <?php echo e($item->numero_comprobante); ?>

                            </p>
                        </td>
                        <td>
                            <p class="fw-semibold mb-1">
                                <span class="badge bg-secondary">
                                    <?php echo e(ucfirst($item->proveedore->persona->tipo_persona)); ?>

                                </span>
                            </p>
                            <p class="text-muted mb-0"><?php echo e($item->proveedore->persona->razon_social); ?></p>
                        </td>
                        <td>
                            <span class="badge bg-info">
                                <i class="fas fa-store"></i> <?php echo e($item->sucursal->nombre); ?>

                            </span>
                        </td>
                        <td>
                            <p class="fw-semibold mb-1">
                                <i class="fa-solid fa-calendar-days"></i>
                                <?php echo e(\Carbon\Carbon::parse($item->fecha_hora)->format('d/m/Y')); ?>

                            </p>
                            <p class="fw-semibold mb-0">
                                <i class="fa-solid fa-clock"></i>
                                <?php echo e(\Carbon\Carbon::parse($item->fecha_hora)->format('H:i')); ?>

                            </p>
                        </td>
                        <td>
                            <strong class="text-success">Q <?php echo e(number_format($item->total, 2)); ?></strong>
                        </td>
                        <td>
                            <small>
                                <i class="fas fa-user"></i> <?php echo e($item->usuario->name ?? 'N/A'); ?>

                            </small>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mostrar-compra')): ?>
                                <a href="<?php echo e(route('compras.show', ['compra'=>$item])); ?>" class="btn btn-success btn-sm">
                                    <i class="fas fa-eye"></i> Ver
                                </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar-compra')): ?>
                                <button type="button" class="btn btn-danger btn-sm"
                                        data-bs-toggle="modal"
                                        data-bs-target="#confirmModal-<?php echo e($item->id); ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>

                    <!-- Modal de confirmación-->
                    <div class="modal fade" id="confirmModal-<?php echo e($item->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-danger text-white">
                                    <h5 class="modal-title">Confirmar Eliminación</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>¿Está seguro que desea eliminar esta compra?</p>
                                    <div class="alert alert-warning">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        <strong>Advertencia:</strong> Esta acción no revertirá automáticamente el inventario.
                                    </div>
                                    <ul>
                                        <li><strong>Comprobante:</strong> <?php echo e($item->numero_comprobante); ?></li>
                                        <li><strong>Proveedor:</strong> <?php echo e($item->proveedore->persona->razon_social); ?></li>
                                        <li><strong>Total:</strong> Q <?php echo e(number_format($item->total, 2)); ?></li>
                                    </ul>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <form action="<?php echo e(route('compras.destroy',['compra'=>$item->id])); ?>" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Confirmar Eliminación</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" type="text/javascript"></script>
<script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/compra/index.blade.php ENDPATH**/ ?>