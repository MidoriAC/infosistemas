<?php $__env->startSection('title','Editar cliente'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Editar Cliente</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('clientes.index')); ?>">Clientes</a></li>
        <li class="breadcrumb-item active">Editar cliente</li>
    </ol>

    <div class="card text-bg-light">
        <form action="<?php echo e(route('clientes.update',['cliente'=>$cliente])); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="card-header">
                <p>Tipo de cliente: <span class="fw-bold"><?php echo e(strtoupper($cliente->persona->tipo_persona)); ?></span></p>
            </div>
            <div class="card-body">

                <div class="row g-3">

                    <!----NIT (Obligatorio)----->
                    <div class="col-md-6">
                        <label for="nit" class="form-label">NIT: <span class="text-danger">*</span></label>
                        <input required type="text" name="nit" id="nit" class="form-control" value="<?php echo e(old('nit', $cliente->persona->nit)); ?>" placeholder="Ejemplo: 12345678-9">
                        <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-------Razón social------->
                    <div class="col-md-6">
                        <?php if($cliente->persona->tipo_persona == 'natural'): ?>
                        <label id="label-natural" for="razon_social" class="form-label">Nombres y apellidos: <span class="text-danger">*</span></label>
                        <?php else: ?>
                        <label id="label-juridica" for="razon_social" class="form-label">Nombre de la empresa: <span class="text-danger">*</span></label>
                        <?php endif; ?>

                        <input required type="text" name="razon_social" id="razon_social" class="form-control" value="<?php echo e(old('razon_social',$cliente->persona->razon_social)); ?>">

                        <?php $__errorArgs = ['razon_social'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!------Nombre comercial (opcional)---->
                    <div class="col-md-6">
                        <label for="nombre_comercial" class="form-label">Nombre comercial: <small class="text-muted">(Opcional)</small></label>
                        <input type="text" name="nombre_comercial" id="nombre_comercial" class="form-control" value="<?php echo e(old('nombre_comercial', $cliente->persona->nombre_comercial)); ?>">
                        <?php $__errorArgs = ['nombre_comercial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!------Dirección---->
                    <div class="col-md-6">
                        <label for="direccion" class="form-label">Dirección: <span class="text-danger">*</span></label>
                        <input required type="text" name="direccion" id="direccion" class="form-control" value="<?php echo e(old('direccion',$cliente->persona->direccion)); ?>">
                        <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!------Email (opcional)---->
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email: <small class="text-muted">(Opcional)</small></label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo e(old('email', $cliente->persona->email)); ?>" placeholder="ejemplo@correo.com">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!------Teléfono (opcional)---->
                    <div class="col-md-6">
                        <label for="telefono" class="form-label">Teléfono: <small class="text-muted">(Opcional)</small></label>
                        <input type="text" name="telefono" id="telefono" class="form-control" value="<?php echo e(old('telefono', $cliente->persona->telefono)); ?>" placeholder="5555-5555">
                        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!------Separador visual---->
                    <div class="col-12">
                        <hr>
                        <h6 class="text-muted">Documento adicional (Opcional)</h6>
                        <small class="text-muted">Si el cliente cuenta con DPI, pasaporte, licencia u otro documento, puede registrarlo aquí.</small>
                    </div>

                    <!--------------Documento (Opcional)------->
                    <div class="col-md-6">
                        <label for="documento_id" class="form-label">Tipo de documento: <small class="text-muted">(Opcional)</small></label>
                        <select class="form-select" name="documento_id" id="documento_id">
                            <option value="">Seleccione una opción</option>
                            <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($cliente->persona->documento_id == $item->id): ?>
                            <option selected value="<?php echo e($item->id); ?>" <?php echo e(old('documento_id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->tipo_documento); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('documento_id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->tipo_documento); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['documento_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-6">
                        <label for="numero_documento" class="form-label">Número de documento: <small class="text-muted">(Opcional)</small></label>
                        <input type="text" name="numero_documento" id="numero_documento" class="form-control" value="<?php echo e(old('numero_documento',$cliente->persona->numero_documento)); ?>">
                        <?php $__errorArgs = ['numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e('*'.$message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

            </div>
            <div class="card-footer text-center">
                <button type="submit" class="btn btn-primary">Actualizar</button>
                <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/cliente/edit.blade.php ENDPATH**/ ?>