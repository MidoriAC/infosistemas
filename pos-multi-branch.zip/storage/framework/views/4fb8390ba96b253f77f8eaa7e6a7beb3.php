<?php $__env->startSection('title','Inventario por Sucursal'); ?>

<?php $__env->startPush('css-datatable'); ?>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .stock-badge {
        font-size: 1rem;
        padding: 0.5em 0.8em;
    }
    .stock-bajo {
        background-color: #dc3545 !important;
    }
    .stock-medio {
        background-color: #ffc107 !important;
    }
    .stock-alto {
        background-color: #28a745 !important;
    }
    .stat-card {
        transition: transform 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Inventario por Sucursal</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Inventario</li>
    </ol>

    <!-- Selector de Sucursal -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('inventario-sucursal.index')); ?>" method="GET" class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label for="sucursal_id" class="form-label">
                        <i class="fas fa-store"></i> Seleccionar Sucursal:
                    </label>
                    <select name="sucursal_id" id="sucursal_id" class="form-select" onchange="this.form.submit()">
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sucursal->id); ?>" <?php if($sucursalSeleccionada == $sucursal->id): echo 'selected'; endif; ?>>
                            <?php echo e($sucursal->nombre); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <div class="d-flex gap-2">
                        
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tarjetas de Estadísticas -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Total Productos</div>
                            <div class="h2 mb-0"><?php echo e($estadisticas['total_productos']); ?></div>
                        </div>
                        <i class="fas fa-boxes fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Stock Total</div>
                            <div class="h2 mb-0"><?php echo e(number_format($estadisticas['stock_total'])); ?></div>
                        </div>
                        <i class="fas fa-cubes fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Valor Inventario</div>
                            <div class="h2 mb-0">Q <?php echo e(number_format($estadisticas['valor_inventario'], 2)); ?></div>
                        </div>
                        <i class="fas fa-dollar-sign fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4 stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-white-50 small">Bajo Mínimo</div>
                            <div class="h2 mb-0"><?php echo e($estadisticas['productos_bajo_minimo']); ?></div>
                        </div>
                        <i class="fas fa-exclamation-triangle fa-3x text-white-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabla de Inventario -->
    <div class="card">
        <div class="card-header">
            <i class="fas fa-warehouse me-1"></i>
            Inventario - <?php echo e($sucursales->firstWhere('id', $sucursalSeleccionada)->nombre ?? 'Sucursal'); ?>

        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-hover fs-6">
                <thead>
                    <tr>
                        
                        <th>Código</th>
                        <th>Producto</th>
                        <th>Marca</th>
                        <th>Ubicación</th>
                        <th>Stock Actual</th>
                        <th>Stock Mín/Máx</th>
                        <th>Precio Venta</th>
                        <th>Valor Total</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inventarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><strong><?php echo e($item->producto->codigo); ?></strong></td>
                        <td>
                            <?php echo e($item->producto->nombre); ?>

                            <?php if($item->producto->presentacione): ?>
                            <br><small class="text-muted"><?php echo e($item->producto->presentacione->caracteristica->nombre); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($item->producto->marca): ?>
                            <span class="badge bg-primary"><?php echo e($item->producto->marca->caracteristica->nombre); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($item->ubicacion): ?>
                            <span class="badge bg-info"><?php echo e($item->ubicacion->codigo); ?></span>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                                $porcentaje = $item->stock_maximo > 0 ? ($item->stock_actual / $item->stock_maximo) * 100 : 0;
                                $badgeClass = 'stock-alto';
                                if ($item->stock_actual <= $item->stock_minimo) {
                                    $badgeClass = 'stock-bajo';
                                } elseif ($porcentaje < 50) {
                                    $badgeClass = 'stock-medio';
                                }
                            ?>
                            <span class="badge <?php echo e($badgeClass); ?> stock-badge">
                                <?php echo e($item->stock_actual); ?>

                                <?php if($item->producto->unidadMedida): ?>
                                    <?php echo e($item->producto->unidadMedida->abreviatura); ?>

                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <small>
                                Mín: <strong><?php echo e($item->stock_minimo); ?></strong><br>
                                Máx: <strong><?php echo e($item->stock_maximo); ?></strong>
                            </small>
                        </td>
                        <td>
                            <strong>Q <?php echo e(number_format($item->precio_venta, 2)); ?></strong>
                        </td>
                        <td>
                            <strong class="text-success">
                                Q <?php echo e(number_format($item->stock_actual * $item->precio_venta, 2)); ?>

                            </strong>
                        </td>
                        <td>
                            <?php if($item->stock_actual <= $item->stock_minimo): ?>
                            <span class="badge bg-danger">
                                <i class="fas fa-exclamation-triangle"></i> Bajo Stock
                            </span>
                            <?php elseif($item->stock_actual == 0): ?>
                            <span class="badge bg-dark">
                                <i class="fas fa-times"></i> Sin Stock
                            </span>
                            <?php else: ?>
                            <span class="badge bg-success">
                                <i class="fas fa-check"></i> Normal
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-sm btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="fas fa-cog"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    
                                    
                                    <li>
                                        <button class="dropdown-item" data-bs-toggle="modal" data-bs-target="#configModal-<?php echo e($item->id); ?>">
                                            <i class="fas fa-cog"></i> Configurar
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>

                    <!-- Modal Configuración -->
                    <div class="modal fade" id="configModal-<?php echo e($item->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-primary text-white">
                                    <h5 class="modal-title">Configurar Inventario</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <form action="<?php echo e(route('inventario-sucursal.update-config', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <strong><?php echo e($item->producto->nombre); ?></strong>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Stock Mínimo:</label>
                                            <input type="number" name="stock_minimo" class="form-control" value="<?php echo e($item->stock_minimo); ?>" min="0" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Stock Máximo:</label>
                                            <input type="number" name="stock_maximo" class="form-control" value="<?php echo e($item->stock_maximo); ?>" min="0" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Precio Venta (Q):</label>
                                            <input type="number" name="precio_venta" class="form-control" value="<?php echo e($item->precio_venta); ?>" min="0" step="0.01" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Ubicación:</label>
                                            <select name="ubicacion_id" class="form-select">
                                                <option value="">Sin ubicación</option>
                                                <?php $__currentLoopData = App\Models\Ubicacion::where('sucursal_id', $item->sucursal_id)->where('estado', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($ubicacion->id); ?>" <?php if($item->ubicacion_id == $ubicacion->id): echo 'selected'; endif; ?>>
                                                    <?php echo e($ubicacion->codigo); ?> - <?php echo e($ubicacion->nombre); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" type="text/javascript"></script>
<script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/inventario-sucursal/index.blade.php ENDPATH**/ ?>