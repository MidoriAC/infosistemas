<?php $__env->startSection('title','Crear Venta'); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta3/dist/css/bootstrap-select.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
    .required:after {
        content: " *";
        color: red;
    }

    @keyframes parpadeo {
        0%, 100% { background-color: #fff3cd; }
        50% { background-color: #dc3545; color: white; }
    }

    .stock-bajo {
        animation: parpadeo 1.5s infinite;
        font-weight: bold;
    }

    .stock-critico {
        background-color: #dc3545 !important;
        color: white !important;
        animation: parpadeo 0.8s infinite;
    }

    .tipo-factura-card {
        cursor: pointer;
        transition: all 0.3s;
        border: 2px solid transparent;
        height: 100%;
    }

    .tipo-factura-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    .tipo-factura-card.selected {
        border-color: #0d6efd;
        background-color: #e7f1ff;
    }

    .info-cotizacion {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
    }

    .info-sucursal {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 15px;
    }

    #resultados_busqueda .list-group-item {
    cursor: pointer;
    transition: all 0.2s;
}

#resultados_busqueda .list-group-item:hover {
    background-color: #e7f1ff;
    border-left: 4px solid #0d6efd;
}

.stock-badge {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
}

.ubicacion-tag {
    display: inline-block;
    background: #6c757d;
    color: white;
    padding: 0.15rem 0.5rem;
    border-radius: 0.25rem;
    font-size: 0.75rem;
    margin-left: 0.5rem;
}

.producto-item {
    padding: 0.75rem;
}

.producto-codigo {
    font-family: 'Courier New', monospace;
    font-weight: bold;
    color: #0d6efd;
}

#buscar_producto:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}

.scanning {
    animation: pulse 1.5s infinite;
}

@keyframes pulse {
    0%, 100% { border-color: #0d6efd; }
    50% { border-color: #0dcaf0; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">
        <?php if($cotizacion): ?>
            <i class="fas fa-sync-alt"></i> Convertir Cotización a Venta
        <?php else: ?>
            <i class="fas fa-cash-register"></i> Nueva Venta
        <?php endif; ?>
    </h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('ventas.index')); ?>">Ventas</a></li>
        <li class="breadcrumb-item active">Crear Venta</li>
    </ol>

    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

    <?php if($cotizacion): ?>
    <div class="info-cotizacion">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h4><i class="fas fa-file-invoice"></i> Datos de la Cotización</h4>
                <p class="mb-1"><strong>Número:</strong> <?php echo e($cotizacion->numero_cotizacion); ?></p>
                <p class="mb-1"><strong>Cliente:</strong> <?php echo e($cotizacion->cliente->persona->razon_social); ?></p>
                <p class="mb-0"><strong>Total:</strong> Q <?php echo e(number_format($cotizacion->total, 2)); ?></p>
            </div>
            <div class="col-md-4 text-center">
                <i class="fas fa-sync-alt fa-3x"></i>
                <p class="mb-0 mt-2">Convirtiendo a Venta</p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Información de sucursal activa -->
    
</div>

<form action="<?php echo e(route('ventas.store')); ?>" method="post" id="formVenta">
    <?php echo csrf_field(); ?>
    
    <?php if($cotizacion): ?>
        <input type="hidden" name="cotizacion_id" value="<?php echo e($cotizacion->id); ?>">
    <?php endif; ?>

    <div class="container-lg mt-4">
        <div class="row gy-4">

            <!------Detalles de la venta---->
            <div class="col-xl-8">
                <div class="text-white bg-primary p-1 text-center">
                    <h5 class="mb-0">Detalles de la Venta</h5>
                </div>
                <div class="p-3 border border-3 border-primary">
                    <div class="row gy-3">

                        <!-----Producto---->
                        

 <!-----Sección de productos dentro del formulario---->
<div class="row gy-3">

    <!-----Buscador de productos---->
    <div class="col-md-12">
        <label class="form-label">Buscar Producto (Manual o Scanner):</label>
        <div class="input-group">
            <span class="input-group-text bg-primary text-white">
                <i class="fas fa-barcode"></i>
            </span>
            <input
                type="text"
                id="buscar_producto"
                class="form-control form-control-lg"
                placeholder="Escanee código de barras o escriba para buscar..."
                autocomplete="off"
                <?php if($cotizacion): ?> disabled <?php endif; ?>
            >
            <button class="btn btn-outline-secondary" type="button" id="limpiar_busqueda">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <!-- Resultados de búsqueda (dropdown) -->
        <div id="resultados_busqueda" class="list-group position-absolute"
             style="z-index: 1000; max-height: 300px; overflow-y: auto; display: none; width: 50%;">
        </div>

        <small class="text-muted">
            <i class="fas fa-info-circle"></i>
            Escanee el código o escriba el nombre/código del producto
        </small>
    </div>

    <!-- INFO DEL PRODUCTO SELECCIONADO -->
    <div class="col-12" id="info_producto" style="display: none;">
        <div class="alert alert-info border-start border-primary border-4 mb-3">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <strong><i class="fas fa-box"></i> Producto:</strong>
                    <p class="mb-0" id="nombre_producto_sel"></p>
                </div>
                <div class="col-md-2">
                    <strong><i class="fas fa-warehouse"></i> Stock:</strong>
                    <p class="mb-0">
                        <span id="stock_producto_sel" class="badge bg-primary"></span>
                    </p>
                </div>
                <div class="col-md-3">
                    <strong><i class="fas fa-map-marker-alt"></i> Ubicación:</strong>
                    <p class="mb-0" id="ubicacion_producto_sel"></p>
                </div>
                <div class="col-md-2">
                    <strong><i class="fas fa-dollar-sign"></i> Precio:</strong>
                    <p class="mb-0" id="precio_producto_sel"></p>
                </div>
                <div class="col-md-2 text-end">
                    <button type="button" class="btn btn-sm btn-outline-danger" id="cancelar_seleccion">
                        <i class="fas fa-times"></i> Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-----Precio de venta---->
    <div class="col-md-3">
        <label for="precio_venta" class="form-label required">Precio Venta:</label>
        <div class="input-group">
            <span class="input-group-text">Q</span>
            <input type="number" name="precio_venta" id="precio_venta"
                   class="form-control" step="0.01" min="0" disabled>
        </div>
    </div>

    <!-----Cantidad---->
    <div class="col-md-3">
        <label for="cantidad" class="form-label required">Cantidad:</label>
        <input type="number" name="cantidad" id="cantidad"
               class="form-control" min="1" step="1" disabled>
    </div>

    <!----Descuento---->
    <div class="col-md-3">
        <label for="descuento" class="form-label">Descuento:</label>
        <div class="input-group">
            <span class="input-group-text">Q</span>
            <input type="number" name="descuento" id="descuento"
                   class="form-control" min="0" step="0.01" value="0" disabled>
        </div>
    </div>

    <!-----Botón agregar--->
    <div class="col-md-3 d-flex align-items-end">
        <button id="btn_agregar" class="btn btn-primary w-100" type="button" disabled
                <?php if($cotizacion): ?> style="display:none" <?php endif; ?>>
            <i class="fas fa-plus"></i> Agregar
        </button>
    </div>

    <!-----Tabla de productos--->
    <div class="col-12">
        <div class="table-responsive">
            <table id="tabla_detalle" class="table table-hover table-bordered">
                <thead >
                    <tr>
                        <th style="width: 5%">#</th>
                        <th style="width: 35%">Producto</th>
                        <th style="width: 10%">Cantidad</th>
                        <th style="width: 15%">Precio</th>
                        <th style="width: 12%">Descuento</th>
                        <th style="width: 15%">Subtotal</th>
                        <th style="width: 8%">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($cotizacion): ?>
                        <?php $__currentLoopData = $cotizacion->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <input type="hidden" name="arrayidproducto[]" value="<?php echo e($producto->id); ?>">
                                <strong><?php echo e($producto->codigo); ?></strong><br>
                                <small class="text-muted"><?php echo e($producto->nombre); ?></small>
                            </td>
                            <td>
                                <input type="hidden" name="arraycantidad[]" value="<?php echo e($producto->pivot->cantidad); ?>">
                                <span class="badge bg-primary"><?php echo e($producto->pivot->cantidad); ?></span>
                            </td>
                            <td>
                                <input type="hidden" name="arrayprecioventa[]" value="<?php echo e($producto->pivot->precio_unitario); ?>">
                                Q <?php echo e(number_format($producto->pivot->precio_unitario, 2)); ?>

                            </td>
                            <td>
                                <input type="hidden" name="arraydescuento[]" value="<?php echo e($producto->pivot->descuento); ?>">
                                Q <?php echo e(number_format($producto->pivot->descuento, 2)); ?>

                            </td>
                            <td><strong>Q <?php echo e(number_format($producto->pivot->subtotal, 2)); ?></strong></td>
                            <td>-</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            <i class="fas fa-inbox fa-2x"></i>
                            <p>No hay productos agregados</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    
                    
                    <tr class="table-primary">
                        <th colspan="5" class="text-end">TOTAL:</th>
                        <th colspan="2">
                            <input type="hidden" name="total" value="<?php echo e($cotizacion ? $cotizacion->total : 0); ?>" id="inputTotal">
                            <input type="hidden" name="impuesto" id="impuesto" value="<?php echo e($cotizacion ? $cotizacion->impuesto : 0); ?>">
                            Q <span id="total"><?php echo e($cotizacion ? number_format($cotizacion->total, 2) : '0.00'); ?></span>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!--Botón cancelar-->
    <div class="col-12">
        <button id="cancelar" type="button" class="btn btn-danger"
                data-bs-toggle="modal" data-bs-target="#cancelModal"
                <?php if($cotizacion): ?> style="display: block;" <?php else: ?> style="display: none;" <?php endif; ?>>
            <i class="fas fa-times"></i> Cancelar Venta
        </button>
    </div>

</div>

                        <!-----Stock Info---->
                        

                        <!--Botón cancelar-->
                        

                    </div>
                </div>
            </div>

            <!-----Datos Generales---->
            <div class="col-xl-4">
                <div class="text-white bg-success p-1 text-center">
                    <h5 class="mb-0">Datos Generales</h5>
                </div>
                <div class="p-3 border border-3 border-success">
                    <div class="row gy-3">

                        <!--Tipo de Factura-->
                        
                        <div class="col-12">
                            <label class="form-label required">Tipo de Factura:</label>
                            <div class="row g-2">
                                <div class="col-6">
                                    <div class="card tipo-factura-card" data-tipo="RECI" id="card-recibo">
                                        <div class="card-body text-center p-3">
                                            <i class="fas fa-receipt fa-2x text-primary mb-2"></i>
                                            <p class="mb-0"><strong>Recibo Simple</strong></p>
                                            <small class="text-muted">Documento interno</small>
                                        </div>
                                    </div>
                                </div>
                                <?php if($tieneFEL): ?>
                                <div class="col-6">
                                    <div class="card tipo-factura-card" data-tipo="FACT" id="card-fel">
                                        <div class="card-body text-center p-3">
                                            <i class="fas fa-file-invoice fa-2x text-success mb-2"></i>
                                            <p class="mb-0"><strong>Factura FEL</strong></p>
                                            <small class="text-muted">Certificada SAT</small>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="tipo_factura" id="tipo_factura" required>
                            <?php $__errorArgs = ['tipo_factura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger d-block mt-1"><?php echo e('*'.$message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        

                        <!--Cliente-->
                        <div class="col-12">
                            <label for="cliente_id" class="form-label required">Cliente:</label>
                            <select name="cliente_id" id="cliente_id"
                                    class="form-control selectpicker show-tick <?php $__errorArgs = ['cliente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    data-live-search="true" title="Seleccione cliente" data-size='3' required>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"
                                        <?php if($cotizacion && $cotizacion->cliente_id == $item->id): ?> selected <?php endif; ?>
                                        <?php if(old('cliente_id')==$item->id): echo 'selected'; endif; ?>>
                                    <?php echo e($item->persona->razon_social); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cliente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e('*'.$message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!--Comprobante-->
                        

                        <!--Impuesto-->
                        

                        <!--Fecha-->
                        <div class="col-6">
                            <label for="fecha" class="form-label">Fecha:</label>
                            <input readonly type="date" name="fecha" id="fecha"
                                   class="form-control border-success"
                                   value="<?php echo date("Y-m-d") ?>">
                            <?php
                            use Carbon\Carbon;
                            $fecha_hora = Carbon::now()->toDateTimeString();
                            ?>
                            <input type="hidden" name="fecha_hora" value="<?php echo e($fecha_hora); ?>">
                        </div>

                        <!--Información-->
                        <div class="col-12">
                            <div class="alert alert-info mb-0" role="alert">
                                <i class="fas fa-info-circle"></i>
                                <strong>Nota:</strong>
                                <?php if($tieneFEL): ?>
                                    El número de documento será generado automáticamente por el sistema.
                                    Si selecciona FEL, la factura será certificada con SAT.
                                <?php else: ?>
                                    Esta sucursal no tiene configuración FEL activa. Solo puede emitir recibos.
                                <?php endif; ?>
                            </div>
                        </div>

                        <!--Botón guardar-->
                        <div class="col-12 text-center mt-3">
                            <button type="submit" class="btn btn-success btn-lg w-100" id="guardar"
                                    <?php if(!$cotizacion): ?> style="display: none;" <?php endif; ?>>
                                <i class="fas fa-cash-register"></i> Realizar Venta
                            </button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal cancelar -->
    <div class="modal fade" id="cancelModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Advertencia</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    ¿Seguro que quieres cancelar la venta? Se perderán todos los productos agregados.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, continuar</button>
                    <button id="btnCancelarVenta" type="button" class="btn btn-danger" data-bs-dismiss="modal">
                        Sí, cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta3/dist/js/bootstrap-select.min.js"></script>
<script>
$(document).ready(function() {
    <?php if(!$cotizacion): ?>
    disableButtons();
    <?php endif; ?>

    // Seleccionar tipo de factura
    $('.tipo-factura-card').click(function() {
        $('.tipo-factura-card').removeClass('selected');
        $(this).addClass('selected');
        const tipo = $(this).data('tipo');
        $('#tipo_factura').val(tipo);
    });

    $('#producto_id').change(function() {
        mostrarValores();
    });

    // $('#btn_agregar').click(function() {
    //     agregarProducto();
    // });

    $('#btnCancelarVenta').click(function() {
        cancelarVenta();
    });

    // $('#formVenta').submit(function(e) {
    //     if (total === 0) {
    //         e.preventDefault();
    //         showModal('Debe agregar al menos un producto a la venta', 'error');
    //         return false;
    //     }

    //     if (!$('#tipo_factura').val() && !<?php echo json_encode($cotizacion ? true : false, 15, 512) ?>) {
    //         e.preventDefault();
    //         showModal('Debe seleccionar un tipo de factura', 'error');
    //         return false;
    //     }

    //     return confirm('¿Está seguro de realizar esta venta?');
    // });
});

let cont = <?php if($cotizacion): ?> <?php echo e($cotizacion->productos->count()); ?> <?php else: ?> 0 <?php endif; ?>;
let subtotal = [];
let sumas = <?php if($cotizacion): ?> <?php echo e($cotizacion->subtotal); ?> <?php else: ?> 0 <?php endif; ?>;
let iva = <?php if($cotizacion): ?> <?php echo e($cotizacion->impuesto); ?> <?php else: ?> 0 <?php endif; ?>;
let total = <?php if($cotizacion): ?> <?php echo e($cotizacion->total); ?> <?php else: ?> 0 <?php endif; ?>;
const impuesto = 12;

<?php if($cotizacion): ?>
    <?php $__currentLoopData = $cotizacion->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        subtotal[<?php echo e($index); ?>] = <?php echo e($producto->pivot->subtotal); ?>;
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

function mostrarValores() {
    const selected = $('#producto_id option:selected');
    const stock = selected.data('stock');
    const stockMin = selected.data('stock-min');
    const precio = selected.data('precio');

    $('#stock').val(stock);
    $('#precio_venta').val(precio);

    if (stock <= stockMin) {
        $('#stock').addClass('stock-bajo');
        $('#stock-warning').show();

        if (stock === 0) {
            $('#stock').addClass('stock-critico');
            showModal('¡ATENCIÓN! Producto sin stock disponible', 'warning');
        }
    } else {
        $('#stock').removeClass('stock-bajo stock-critico');
        $('#stock-warning').hide();
    }
}

function agregarProducto() {
    const selected = $('#producto_id option:selected');
    const idProducto = selected.val();
    const nombreProducto = selected.data('nombre');
    const codigoProducto = selected.data('codigo');
    const stockDisponible = parseInt(selected.data('stock'));
    const cantidad = parseInt($('#cantidad').val()) || 0;
    const precioVenta = parseFloat($('#precio_venta').val()) || 0;
    const descuento = parseFloat($('#descuento').val()) || 0;

    if (!idProducto || !nombreProducto || !cantidad || !precioVenta) {
        showModal('Complete todos los campos requeridos', 'error');
        return;
    }

    if (cantidad <= 0) {
        showModal('La cantidad debe ser mayor a 0', 'error');
        return;
    }

    if (precioVenta <= 0) {
        showModal('El precio debe ser mayor a 0', 'error');
        return;
    }

    if (cantidad > stockDisponible) {
        showModal(`Stock insuficiente. Disponible: ${stockDisponible}`, 'error');
        return;
    }

    if (descuento < 0) {
        showModal('El descuento no puede ser negativo', 'error');
        return;
    }

    const subtotalProducto = (cantidad * precioVenta);
    if (descuento > subtotalProducto) {
        showModal('El descuento no puede ser mayor al subtotal del producto', 'error');
        return;
    }

    let existe = false;
    $('#tabla_detalle tbody tr').each(function() {
        const id = $(this).find('input[name="arrayidproducto[]"]').val();
        if (id == idProducto) {
            existe = true;
            return false;
        }
    });

    if (existe) {
        showModal('El producto ya fue agregado. Elimínelo primero si desea modificarlo', 'warning');
        return;
    }

    subtotal[cont] = round((cantidad * precioVenta) - descuento);
    sumas += subtotal[cont];
    iva = round(sumas * (impuesto / 100));
    total = round(sumas);

    if ($('#tabla_detalle tbody tr td').attr('colspan') == '7') {
        $('#tabla_detalle tbody').empty();
    }

    let fila = '<tr id="fila' + cont + '">' +
        '<td class="text-center">' + (cont + 1) + '</td>' +
        '<td>' +
            '<input type="hidden" name="arrayidproducto[]" value="' + idProducto + '">' +
            '<strong>' + codigoProducto + '</strong><br>' +
            '<small class="text-muted">' + nombreProducto + '</small>' +
        '</td>' +
        '<td class="text-center">' +
            '<input type="hidden" name="arraycantidad[]" value="' + cantidad + '">' +
            '<span class="badge bg-primary">' + cantidad + '</span>' +
        '</td>' +
        '<td class="text-end">' +
            '<input type="hidden" name="arrayprecioventa[]" value="' + precioVenta + '">' +
            'Q ' + precioVenta.toFixed(2) +
        '</td>' +
        '<td class="text-end">' +
            '<input type="hidden" name="arraydescuento[]" value="' + descuento + '">' +
            'Q ' + descuento.toFixed(2) +
        '</td>' +
        '<td class="text-end"><strong>Q ' + subtotal[cont].toFixed(2) + '</strong></td>' +
        '<td class="text-center">' +
            '<button class="btn btn-danger btn-sm" type="button" onClick="eliminarProducto(' + cont + ')" title="Eliminar producto">' +
                '<i class="fas fa-trash"></i>' +
            '</button>' +
        '</td>' +
    '</tr>';

    $('#tabla_detalle tbody').append(fila);
    limpiarCampos();
    cont++;
    disableButtons();

    $('#sumas').html(sumas.toFixed(2));
    $('#iva').html(iva.toFixed(2));
    $('#total').html(total.toFixed(2));
    $('#impuesto').val(iva.toFixed(2));
    $('#inputTotal').val(total.toFixed(2));

    showModal('Producto agregado correctamente', 'success');
}

function eliminarProducto(indice) {
    sumas -= round(subtotal[indice]);
    iva = round(sumas * (impuesto / 100));
    // total = round(sumas + iva);
    total = round(sumas);

    $('#sumas').html(sumas.toFixed(2));
    $('#iva').html(iva.toFixed(2));
    $('#total').html(total.toFixed(2));
    $('#impuesto').val(iva.toFixed(2));
    $('#inputTotal').val(total.toFixed(2));

    $('#fila' + indice).remove();

    $('#tabla_detalle tbody tr').each(function(index) {
        $(this).find('td:first').text(index + 1);
    });

    if ($('#tabla_detalle tbody tr').length === 0) {
        $('#tabla_detalle tbody').html(`
            <tr>
                <td colspan="7" class="text-center text-muted">
                    <i class="fas fa-inbox fa-2x"></i>
                    <p>No hay productos agregados</p>
                </td>
            </tr>
        `);
    }

    disableButtons();
    showModal('Producto eliminado', 'info');
}

function cancelarVenta() {
    $('#tabla_detalle tbody').html(`
        <tr>
            <td colspan="7" class="text-center text-muted">
                <i class="fas fa-inbox fa-2x"></i>
                <p>No hay productos agregados</p>
            </td>
        </tr>
    `);

    cont = 0;
    subtotal = [];
    sumas = 0;
    iva = 0;
    total = 0;

    $('#sumas').html('0.00');
    $('#iva').html('0.00');
    $('#total').html('0.00');
    $('#impuesto').val('0.00');
    $('#inputTotal').val('0');

    limpiarCampos();
    disableButtons();

    $('.tipo-factura-card').removeClass('selected');
    $('#tipo_factura').val('');
}

function disableButtons() {
    if (total == 0) {
        $('#guardar').hide();
        $('#cancelar').hide();
    } else {
        $('#guardar').show();
        $('#cancelar').show();
    }
}

function limpiarCampos() {
    $('#producto_id').selectpicker('val', '');
    $('#cantidad').val('');
    $('#precio_venta').val('');
    $('#descuento').val('0');
    $('#stock').val('0');
    $('#stock').removeClass('stock-bajo stock-critico');
    $('#stock-warning').hide();
}

function round(num, decimales = 2) {
    return Math.round((num + Number.EPSILON) * Math.pow(10, decimales)) / Math.pow(10, decimales);
}

function showModal(message, icon = 'info') {
    const iconColors = {
        'success': '#28a745',
        'error': '#dc3545',
        'warning': '#ffc107',
        'info': '#17a2b8'
    };

    Swal.fire({
        text: message,
        icon: icon,
        iconColor: iconColors[icon],
        confirmButtonColor: iconColors[icon],
        confirmButtonText: 'Aceptar',
        timer: icon === 'success' ? 2000 : null,
        timerProgressBar: icon === 'success',
        toast: icon === 'success',
        position: icon === 'success' ? 'top-end' : 'center',
        showConfirmButton: icon !== 'success'
    });
}

// Variables globales
// let cont = <?php if($cotizacion): ?> <?php echo e($cotizacion->productos->count()); ?> <?php else: ?> 0 <?php endif; ?>;
// let subtotal = [];
// let sumas = <?php if($cotizacion): ?> <?php echo e($cotizacion->subtotal); ?> <?php else: ?> 0 <?php endif; ?>;
// let iva = <?php if($cotizacion): ?> <?php echo e($cotizacion->impuesto); ?> <?php else: ?> 0 <?php endif; ?>;
// let total = <?php if($cotizacion): ?> <?php echo e($cotizacion->total); ?> <?php else: ?> 0 <?php endif; ?>;
// const impuesto = 12;

// Variables para el sistema de búsqueda
let productoSeleccionado = null;
let timeoutBusqueda = null;
let scannerBuffer = '';
let scannerTimeout = null;

<?php if($cotizacion): ?>
    <?php $__currentLoopData = $cotizacion->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        subtotal[<?php echo e($index); ?>] = <?php echo e($producto->pivot->subtotal); ?>;
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

$(document).ready(function() {
    // Inicializar sistema de búsqueda
    inicializarSistemaBusqueda();

    <?php if(!$cotizacion): ?>
    disableButtons();
    <?php endif; ?>

    // Seleccionar tipo de factura
    $('.tipo-factura-card').click(function() {
        $('.tipo-factura-card').removeClass('selected');
        $(this).addClass('selected');
        const tipo = $(this).data('tipo');
        $('#tipo_factura').val(tipo);
    });

    $('#btn_agregar').click(function() {
        agregarProducto();
    });

    $('#btnCancelarVenta').click(function() {
        cancelarVenta();
    });

   $('#formVenta').on('submit', function(e) {
        e.preventDefault(); // Detenemos el envío normal momentáneamente

        // 1. Validaciones básicas de UI
        if (total === 0) {
            showModal('Debe agregar al menos un producto a la venta', 'error');
            return false;
        }

        const tipoFactura = $('#tipo_factura').val();
        // Si no viene de cotización y no ha seleccionado tipo
        if (!tipoFactura && !<?php echo json_encode($cotizacion ? true : false, 15, 512) ?>) {
            showModal('Debe seleccionar un tipo de factura (Recibo o FEL)', 'error');
            return false;
        }

        // 2. Confirmación y Pantalla de Carga
        Swal.fire({
            title: '¿Procesar Venta?',
            text: "Verifique que los datos sean correctos.",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, cobrar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {

                // MOSTRAR LOADING (Bloqueante)
                let timerInterval;
                Swal.fire({
                    title: 'Procesando Venta',
                    html: 'Conectando con certificador... <br><b>Por favor no cierre esta ventana.</b>',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                // Enviar el formulario manualmente ahora que mostramos el loading
                this.submit();
            }
        });
    });
    });

/**
 * Inicializar sistema de búsqueda híbrido
 */
function inicializarSistemaBusqueda() {
    const inputBusqueda = $('#buscar_producto');

    // Detección de scanner de código de barras
    inputBusqueda.on('keypress', function(e) {
        const char = String.fromCharCode(e.which);
        scannerBuffer += char;

        // Limpiar el timeout anterior
        clearTimeout(scannerTimeout);

        // Si se presiona Enter, es un scanner
        if (e.which === 13) {
            e.preventDefault();
            const codigo = scannerBuffer.replace(/[\r\n]/g, '').trim();

            if (codigo.length > 0) {
                inputBusqueda.addClass('scanning');
                buscarPorCodigoExacto(codigo);
            }

            scannerBuffer = '';
            return false;
        }

        // Reset del buffer después de 100ms (indica escritura manual)
        scannerTimeout = setTimeout(() => {
            scannerBuffer = '';
        }, 100);
    });

    // Búsqueda manual con delay
    inputBusqueda.on('input', function() {
        const termino = $(this).val().trim();

        clearTimeout(timeoutBusqueda);

        if (termino.length === 0) {
            ocultarResultados();
            return;
        }

        if (termino.length < 2) {
            return;
        }

        // Delay para no hacer requests en cada tecla
        timeoutBusqueda = setTimeout(() => {
            buscarProductos(termino);
        }, 300);
    });

    // Ocultar resultados al hacer clic fuera
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#buscar_producto, #resultados_busqueda').length) {
            ocultarResultados();
        }
    });

    // Limpiar búsqueda
    $('#limpiar_busqueda').click(function() {
        limpiarBusqueda();
    });

    // Cancelar selección
    $('#cancelar_seleccion').click(function() {
        cancelarSeleccionProducto();
    });

    // Focus en el input al cargar
    if (!<?php echo json_encode($cotizacion ? true : false, 15, 512) ?>) {
        inputBusqueda.focus();
    }
}

/**
 * Buscar productos (búsqueda manual con sugerencias)
 */
function buscarProductos(termino) {
    $.ajax({
        url: '<?php echo e(route("ventas.buscar-producto")); ?>',
        method: 'POST',
        data: {
            _token: '<?php echo e(csrf_token()); ?>',
            termino: termino
        },
        beforeSend: function() {
            mostrarCargando();
        },
        success: function(response) {
            if (response.success && response.productos.length > 0) {
                mostrarResultados(response.productos);
            } else {
                mostrarSinResultados();
            }
        },
        error: function(xhr) {
            console.error('Error al buscar productos:', xhr);
            showModal('Error al buscar productos', 'error');
            ocultarResultados();
        }
    });
}

/**
 * Buscar por código exacto (para scanner)
 */
function buscarPorCodigoExacto(codigo) {
    $.ajax({
        url: '<?php echo e(route("ventas.obtener-por-codigo")); ?>',
        method: 'POST',
        data: {
            _token: '<?php echo e(csrf_token()); ?>',
            codigo: codigo
        },
        success: function(response) {
            if (response.success) {
                $('#buscar_producto').removeClass('scanning');
                seleccionarProducto(response.producto);
                $('#buscar_producto').val('');
                ocultarResultados();

                // Focus en cantidad
                setTimeout(() => {
                    $('#cantidad').focus().select();
                }, 100);

                reproducirSonidoExito();
            }
        },
        error: function(xhr) {
            $('#buscar_producto').removeClass('scanning');

            let mensaje = 'Producto no encontrado';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                mensaje = xhr.responseJSON.message;
            }

            showModal(mensaje, 'error');
            $('#buscar_producto').val('');
            scannerBuffer = '';

            setTimeout(() => {
                $('#buscar_producto').focus();
            }, 100);

            reproducirSonidoError();
        }
    });
}

/**
 * Mostrar resultados de búsqueda
 */
function mostrarResultados(productos) {
    const container = $('#resultados_busqueda');
    container.empty();

    productos.forEach(function(producto) {
        const stockClass = producto.bajo_stock ? 'bg-warning' : 'bg-success';
        const stockIcon = producto.bajo_stock ? 'fa-exclamation-triangle' : 'fa-check';

        const item = $(`
            <div class="list-group-item list-group-item-action producto-item" data-producto='${JSON.stringify(producto)}'>
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1">
                        <h6 class="mb-1">
                            <span class="producto-codigo">${producto.codigo}</span> - ${producto.nombre}
                        </h6>
                        <small class="text-muted">
                            ${producto.marca} | ${producto.presentacion}
                        </small>
                        <span class="ubicacion-tag">
                            <i class="fas fa-map-marker-alt"></i> ${producto.ubicacion.texto_completo}
                        </span>
                    </div>
                    <div class="text-end">
                        <span class="stock-badge badge ${stockClass}">
                            <i class="fas ${stockIcon}"></i> Stock: ${producto.stock_actual}
                        </span>
                        <div class="mt-1">
                            <strong class="text-primary">Q ${parseFloat(producto.precio_venta).toFixed(2)}</strong>
                        </div>
                    </div>
                </div>
            </div>
        `);

        item.click(function() {
            const prod = JSON.parse($(this).attr('data-producto'));
            seleccionarProducto(prod);
            ocultarResultados();
            $('#buscar_producto').val('');

            setTimeout(() => {
                $('#cantidad').focus().select();
            }, 100);
        });

        container.append(item);
    });

    container.show();
}

/**
 * Seleccionar producto
 */
function seleccionarProducto(producto) {
    productoSeleccionado = producto;

    // Mostrar info del producto
    $('#nombre_producto_sel').html(`<strong>${producto.codigo}</strong> - ${producto.nombre}`);
    $('#stock_producto_sel').text(producto.stock_actual + ' unidades');
    $('#ubicacion_producto_sel').html(`
        <span class="badge bg-secondary">
            <i class="fas fa-map-marker-alt"></i> ${producto.ubicacion.texto_completo}
        </span>
    `);
    $('#precio_producto_sel').text('Q ' + parseFloat(producto.precio_venta).toFixed(2));

    // Aplicar clase según stock
    if (producto.bajo_stock) {
        $('#stock_producto_sel').removeClass('bg-primary bg-success').addClass('bg-warning');
    } else {
        $('#stock_producto_sel').removeClass('bg-warning').addClass('bg-success');
    }

    if (producto.stock_actual === 0) {
        $('#stock_producto_sel').removeClass('bg-warning bg-success').addClass('bg-danger');
    }

    $('#info_producto').slideDown(300);

    // Habilitar campos
    $('#precio_venta').val(producto.precio_venta).prop('disabled', false);
    $('#cantidad').val(1).prop('disabled', false);
    $('#descuento').val(0).prop('disabled', false);
    $('#btn_agregar').prop('disabled', false);

    // Deshabilitar búsqueda temporalmente
    $('#buscar_producto').prop('disabled', true);
}

/**
 * Cancelar selección de producto
 */
function cancelarSeleccionProducto() {
    productoSeleccionado = null;
    $('#info_producto').slideUp(300);

    // Deshabilitar campos
    $('#precio_venta').val('').prop('disabled', true);
    $('#cantidad').val('').prop('disabled', true);
    $('#descuento').val(0).prop('disabled', true);
    $('#btn_agregar').prop('disabled', true);

    // Habilitar búsqueda
    $('#buscar_producto').prop('disabled', false).val('').focus();
}

/**
 * Agregar producto a la tabla
 */
function agregarProducto() {
    if (!productoSeleccionado) {
        showModal('Debe seleccionar un producto primero', 'error');
        return;
    }

    const cantidad = parseInt($('#cantidad').val()) || 0;
    const precioVenta = parseFloat($('#precio_venta').val()) || 0;
    const descuento = parseFloat($('#descuento').val()) || 0;

    // Validaciones
    if (cantidad <= 0) {
        showModal('La cantidad debe ser mayor a 0', 'error');
        $('#cantidad').focus();
        return;
    }

    if (precioVenta <= 0) {
        showModal('El precio debe ser mayor a 0', 'error');
        $('#precio_venta').focus();
        return;
    }

    if (cantidad > productoSeleccionado.stock_actual) {
        showModal(`Stock insuficiente. Disponible: ${productoSeleccionado.stock_actual}`, 'error');
        $('#cantidad').focus();
        return;
    }

    const subtotalProducto = (cantidad * precioVenta);
    if (descuento > subtotalProducto) {
        showModal('El descuento no puede ser mayor al subtotal', 'error');
        $('#descuento').focus();
        return;
    }

    // Verificar si ya existe
    let existe = false;
    $('#tabla_detalle tbody tr').each(function() {
        const id = $(this).find('input[name="arrayidproducto[]"]').val();
        if (id == productoSeleccionado.id) {
            existe = true;
            return false;
        }
    });

    if (existe) {
        showModal('El producto ya fue agregado. Elimínelo primero si desea modificarlo', 'warning');
        return;
    }

    // Agregar a la tabla
    subtotal[cont] = round((cantidad * precioVenta) - descuento);
    sumas += subtotal[cont];
    iva = round(sumas * (impuesto / 100));
    total = round(sumas);

    if ($('#tabla_detalle tbody tr td').attr('colspan') == '7') {
        $('#tabla_detalle tbody').empty();
    }

    let fila = '<tr id="fila' + cont + '">' +
        '<td class="text-center">' + (cont + 1) + '</td>' +
        '<td>' +
            '<input type="hidden" name="arrayidproducto[]" value="' + productoSeleccionado.id + '">' +
            '<strong>' + productoSeleccionado.codigo + '</strong><br>' +
            '<small class="text-muted">' + productoSeleccionado.nombre + '</small><br>' +
            '<span class="badge bg-secondary"><i class="fas fa-map-marker-alt"></i> ' +
            productoSeleccionado.ubicacion.codigo + '</span>' +
        '</td>' +
        '<td class="text-center">' +
            '<input type="hidden" name="arraycantidad[]" value="' + cantidad + '">' +
            '<span class="badge bg-primary">' + cantidad + '</span>' +
        '</td>' +
        '<td class="text-end">' +
            '<input type="hidden" name="arrayprecioventa[]" value="' + precioVenta + '">' +
            'Q ' + precioVenta.toFixed(2) +
        '</td>' +
        '<td class="text-end">' +
            '<input type="hidden" name="arraydescuento[]" value="' + descuento + '">' +
            'Q ' + descuento.toFixed(2) +
        '</td>' +
        '<td class="text-end"><strong>Q ' + subtotal[cont].toFixed(2) + '</strong></td>' +
        '<td class="text-center">' +
            '<button class="btn btn-danger btn-sm" type="button" onClick="eliminarProducto(' + cont + ')">' +
                '<i class="fas fa-trash"></i>' +
            '</button>' +
        '</td>' +
    '</tr>';

    $('#tabla_detalle tbody').append(fila);
    cont++;

    actualizarTotales();
    cancelarSeleccionProducto();
    disableButtons();

    showModal('Producto agregado correctamente', 'success');
}

/**
 * Eliminar producto
 */
function eliminarProducto(indice) {
    sumas -= round(subtotal[indice]);
    iva = round(sumas * (impuesto / 100));
    total = round(sumas);

    actualizarTotales();

    $('#fila' + indice).remove();

    $('#tabla_detalle tbody tr').each(function(index) {
        $(this).find('td:first').text(index + 1);
    });

    if ($('#tabla_detalle tbody tr').length === 0) {
        $('#tabla_detalle tbody').html(`
            <tr>
                <td colspan="7" class="text-center text-muted">
                    <i class="fas fa-inbox fa-2x"></i>
                    <p>No hay productos agregados</p>
                </td>
            </tr>
        `);
    }

    disableButtons();
    showModal('Producto eliminado', 'info');
}

/**
 * Cancelar venta
 */
function cancelarVenta() {
    $('#tabla_detalle tbody').html(`
        <tr>
            <td colspan="7" class="text-center text-muted">
                <i class="fas fa-inbox fa-2x"></i>
                <p>No hay productos agregados</p>
            </td>
        </tr>
    `);

    cont = 0;
    subtotal = [];
    sumas = 0;
    iva = 0;
    total = 0;

    actualizarTotales();
    cancelarSeleccionProducto();
    disableButtons();

    $('.tipo-factura-card').removeClass('selected');
    $('#tipo_factura').val('');
}

/**
 * Actualizar totales
 */
function actualizarTotales() {
    $('#sumas').html(sumas.toFixed(2));
    $('#iva').html(iva.toFixed(2));
    $('#total').html(total.toFixed(2));
    $('#impuesto').val(iva.toFixed(2));
    $('#inputTotal').val(total.toFixed(2));
}

/**
 * Deshabilitar/habilitar botones
 */
function disableButtons() {
    if (total == 0) {
        $('#guardar').hide();
        $('#cancelar').hide();
    } else {
        $('#guardar').show();
        $('#cancelar').show();
    }
}

/**
 * Limpiar búsqueda
 */
function limpiarBusqueda() {
    $('#buscar_producto').val('').focus();
    ocultarResultados();
    scannerBuffer = '';
}

/**
 * Ocultar resultados
 */
function ocultarResultados() {
    $('#resultados_busqueda').hide().empty();
}

/**
 * Mostrar cargando
 */
function mostrarCargando() {
    $('#resultados_busqueda').html(`
        <div class="list-group-item text-center">
            <i class="fas fa-spinner fa-spin"></i> Buscando...
        </div>
    `).show();
}

/**
 * Mostrar sin resultados
 */
function mostrarSinResultados() {
    $('#resultados_busqueda').html(`
        <div class="list-group-item text-center text-muted">
            <i class="fas fa-search"></i> No se encontraron productos
        </div>
    `).show();
}

/**
 * Funciones auxiliares
 */
function round(num, decimales = 2) {
    return Math.round((num + Number.EPSILON) * Math.pow(10, decimales)) / Math.pow(10, decimales);
}

function showModal(message, icon = 'info') {
    const iconColors = {
        'success': '#28a745',
        'error': '#dc3545',
        'warning': '#ffc107',
        'info': '#17a2b8'
    };

    Swal.fire({
        text: message,
        icon: icon,
        iconColor: iconColors[icon],
        confirmButtonColor: iconColors[icon],
        confirmButtonText: 'Aceptar',
        timer: icon === 'success' ? 2000 : null,
        timerProgressBar: icon === 'success',
        toast: icon === 'success',
        position: icon === 'success' ? 'top-end' : 'center',
        showConfirmButton: icon !== 'success'
    });
}

function reproducirSonidoExito() {
    console.log('✓ Beep - Producto encontrado');
}

function reproducirSonidoError() {
    console.log('✗ Beep - Error');
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/venta/create.blade.php ENDPATH**/ ?>