<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">

                <div class="sb-sidenav-menu-heading">Inicio</div>
                <a class="nav-link" href="<?php echo e(route('panel')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Panel
                </a>

                <!---div class="sb-sidenav-menu-heading">Interface</div>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Layouts
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="layout-static.html">Static Navigation</a>
                        <a class="nav-link" href="layout-sidenav-light.html">Light Sidenav</a>
                    </nav>
                </div>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                    Pages
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">
                            Authentication
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="login.html">Login</a>
                                <a class="nav-link" href="register.html">Register</a>
                                <a class="nav-link" href="password.html">Forgot Password</a>
                            </nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">
                            Error
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="401.html">401 Page</a>
                                <a class="nav-link" href="404.html">404 Page</a>
                                <a class="nav-link" href="500.html">500 Page</a>
                            </nav>
                        </div>
                    </nav>
                </div--->

                <div class="sb-sidenav-menu-heading">Modulos</div>

                  <!----Ventas---->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-venta')): ?>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseVentas" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-cart-shopping"></i></div>
                    Ventas
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseVentas" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-venta')): ?>
                        <a class="nav-link" href="<?php echo e(route('ventas.index')); ?>">Ver</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-venta')): ?>
                        <a class="nav-link" href="<?php echo e(route('ventas.create')); ?>">Crear</a>
                        <?php endif; ?>
                    </nav>
                </div>
                <?php endif; ?>

                  <!----Cotizaciones---->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-cotizacion')): ?>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseCotizacion" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-bag-shopping"></i></div>
                    Cotizaciones
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseCotizacion" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-cotizacion')): ?>
                        <a class="nav-link" href="<?php echo e(route('cotizaciones.index')); ?>">Ver</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-cotizacion')): ?>
                        <a class="nav-link" href="<?php echo e(route('cotizaciones.create')); ?>">Crear</a>
                        <?php endif; ?>
                    </nav>
                </div>
                <?php endif; ?>

                <!----Compras---->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-compra')): ?>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseCompras" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-store"></i></div>
                    Compras
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseCompras" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-compra')): ?>
                        <a class="nav-link" href="<?php echo e(route('compras.index')); ?>">Ver</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-compra')): ?>
                        <a class="nav-link" href="<?php echo e(route('compras.create')); ?>">Crear</a>
                        <?php endif; ?>
                    </nav>
                </div>
                <?php endif; ?>

                <!----Parametros---->
                
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseParametros" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-pen"></i></i></div>
                    Parametros
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseParametros" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-categoria')): ?>
                        <a class="nav-link" href="<?php echo e(route('categorias.index')); ?>">Categorias</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-presentacione')): ?>
                        <a class="nav-link" href="<?php echo e(route('presentaciones.create')); ?>">Presentaciones</a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-marca')): ?>
                        <a class="nav-link" href="<?php echo e(route('marcas.create')); ?>">Marcas</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-ubicacion')): ?>
                        <a class="nav-link" href="<?php echo e(route('ubicaciones.create')); ?>">Ubicaciones</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-unidad-medida')): ?>
                        <a class="nav-link" href="<?php echo e(route('unidades-medida.index')); ?>">Unidades de medida</a>
                        <?php endif; ?>
                    </nav>
                </div>
                



                
                
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-producto')): ?>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseProductos" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fa-brands fa-shopify"></i></div>
                    Productos
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseProductos" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-producto')): ?>
                        <a class="nav-link" href="<?php echo e(route('productos.index')); ?>">Ver productos</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-producto-danado')): ?>
                        <a class="nav-link" href="<?php echo e(route('productos-danados.index')); ?>">Productos dañados</a>
                        <?php endif; ?>
                        
                    </nav>
                </div>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-inventario')): ?>
                <li class="nav-item">
                    
                    <a class="nav-link"
                    href="<?php echo e(route('inventario-sucursal.index')); ?>">
                        <div class="sb-nav-link-icon">
                            <i class="fas fa-warehouse"></i>
                        </div>
                        Inventario por Sucursal
                    </a>
                </li>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-cliente')): ?>
                <a class="nav-link" href="<?php echo e(route('clientes.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-users"></i></div>
                    Clientes
                </a>
                <?php endif; ?>



                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-proveedore')): ?>
                <a class="nav-link" href="<?php echo e(route('proveedores.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-user-group"></i></div>
                    Proveedores
                </a>
                <?php endif; ?>

                
                
                    
                    
                    
                        
                            
                        
                        
                    
                
                
                
                
                    
                    

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'administrador')): ?>
                <div class="sb-sidenav-menu-heading">OTROS</div>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-reportes')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('reportes.index')); ?>">
                            <i class="fas fa-chart-bar"></i>
                            <span>Reportes</span>
                        </a>
                    </li>
                    <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-user')): ?>
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-user"></i></div>
                    Usuarios
                </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-role')): ?>
                <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-person-circle-plus"></i></div>
                    Roles
                </a>
                <?php endif; ?>


                
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-sucursal')): ?>
                <a class="nav-link" href="<?php echo e(route('sucursales.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-building-user"></i></div>
                    Sucursales
                </a>
                <?php endif; ?>


            </div>
        </div>
      <div class="sb-sidenav-footer">
    <div class="small">Bienvenido:</div>
    <?php if(auth()->check()): ?>
        <?php echo e(auth()->user()->name); ?>

    <?php else: ?>
        Invitado
    <?php endif; ?>
</div>
    </nav>
</div>
<?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/components/navigation-menu.blade.php ENDPATH**/ ?>