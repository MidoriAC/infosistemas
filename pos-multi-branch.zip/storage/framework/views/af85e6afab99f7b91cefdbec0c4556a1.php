<?php $__env->startSection('title','Crear usuario'); ?>

<?php $__env->startPush('css'); ?>
<style>
    .required:after {
        content: " *";
        color: red;
    }
    .sucursal-checkbox {
        margin-bottom: 0.5rem;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Crear Usuario</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Usuarios</a></li>
        <li class="breadcrumb-item active">Crear Usuario</li>
    </ol>

    <div class="card">
        <form action="<?php echo e(route('users.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-header bg-primary text-white">
                <i class="fas fa-user-plus me-2"></i>
                <strong>Formulario de Registro</strong>
            </div>
            <div class="card-body">

                
                <div class="mb-4">
                    <h5 class="border-bottom pb-2">
                        <i class="fas fa-user me-2"></i>Información Personal
                    </h5>
                </div>

                <!---Nombre---->
                <div class="row mb-4">
                    <label for="name" class="col-lg-2 col-form-label required">Nombre:</label>
                    <div class="col-lg-4">
                        <input autocomplete="off"
                               type="text"
                               name="name"
                               id="name"
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('name')); ?>"
                               placeholder="Ej: Juan Pérez">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-info-circle"></i> Nombre completo del usuario
                        </small>
                    </div>
                </div>

                <!---Email---->
                <div class="row mb-4">
                    <label for="email" class="col-lg-2 col-form-label required">Email:</label>
                    <div class="col-lg-4">
                        <input autocomplete="off"
                               type="email"
                               name="email"
                               id="email"
                               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('email')); ?>"
                               placeholder="usuario@ejemplo.com">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-envelope"></i> Correo electrónico para acceder al sistema
                        </small>
                    </div>
                </div>

                
                <div class="mb-4 mt-5">
                    <h5 class="border-bottom pb-2">
                        <i class="fas fa-lock me-2"></i>Contraseña
                    </h5>
                </div>

                <!---Password---->
                <div class="row mb-4">
                    <label for="password" class="col-lg-2 col-form-label required">Contraseña:</label>
                    <div class="col-lg-4">
                        <input type="password"
                               name="password"
                               id="password"
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Mínimo 8 caracteres">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-shield-alt"></i> Debe incluir letras y números (mínimo 8 caracteres)
                        </small>
                    </div>
                </div>

                <!---Confirm_Password---->
                <div class="row mb-4">
                    <label for="password_confirm" class="col-lg-2 col-form-label required">Confirmar:</label>
                    <div class="col-lg-4">
                        <input type="password"
                               name="password_confirm"
                               id="password_confirm"
                               class="form-control <?php $__errorArgs = ['password_confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Repetir contraseña">
                        <?php $__errorArgs = ['password_confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-check-double"></i> Vuelva a escribir la contraseña
                        </small>
                    </div>
                </div>

                
                <div class="mb-4 mt-5">
                    <h5 class="border-bottom pb-2">
                        <i class="fas fa-user-shield me-2"></i>Rol y Permisos
                    </h5>
                </div>

                <!---Roles---->
                <div class="row mb-4">
                    <label for="role" class="col-lg-2 col-form-label required">Rol:</label>
                    <div class="col-lg-4">
                        <select name="role"
                                id="role"
                                class="form-select <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="" selected disabled>Seleccione un rol</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->name); ?>"
                                    <?php if(old('role')==$item->name): echo 'selected'; endif; ?>>
                                <?php echo e(ucfirst($item->name)); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-users-cog"></i> Define los permisos del usuario
                        </small>
                    </div>
                </div>

                
                <div class="mb-4 mt-5">
                    <h5 class="border-bottom pb-2">
                        <i class="fas fa-store me-2"></i>Asignación de Sucursales
                    </h5>
                </div>

                <!---Sucursales---->
                <div class="row mb-4">
                    <label class="col-lg-2 col-form-label required">Sucursales:</label>
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <?php if($sucursales->count() > 0): ?>
                                    <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check sucursal-checkbox">
                                        <input class="form-check-input sucursal-check"
                                               type="checkbox"
                                               name="sucursales[]"
                                               value="<?php echo e($sucursal->id); ?>"
                                               id="sucursal<?php echo e($sucursal->id); ?>"
                                               <?php echo e(in_array($sucursal->id, old('sucursales', [])) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="sucursal<?php echo e($sucursal->id); ?>">
                                            <strong><?php echo e($sucursal->nombre); ?></strong>
                                            <span class="badge bg-primary"><?php echo e($sucursal->codigo); ?></span>
                                            <?php if($sucursal->direccion): ?>
                                            <br><small class="text-muted"><?php echo e($sucursal->direccion); ?></small>
                                            <?php endif; ?>
                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="alert alert-warning" role="alert">
                                        <i class="fas fa-exclamation-triangle"></i>
                                        No hay sucursales disponibles.
                                        <a href="<?php echo e(route('sucursales.create')); ?>">Crear una sucursal</a>
                                    </div>
                                <?php endif; ?>
                                <?php $__errorArgs = ['sucursales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-2">
                                    <small><?php echo e($message); ?></small>
                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <small class="form-text text-muted mt-2">
                            <i class="fas fa-info-circle"></i> Seleccione las sucursales donde trabajará el usuario
                        </small>
                    </div>
                </div>

                <!---Sucursal Principal---->
                <div class="row mb-4">
                    <label for="sucursal_principal" class="col-lg-2 col-form-label">Sucursal Principal:</label>
                    <div class="col-lg-4">
                        <select name="sucursal_principal"
                                id="sucursal_principal"
                                class="form-select <?php $__errorArgs = ['sucursal_principal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Sin sucursal principal</option>
                            <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sucursal->id); ?>"
                                    class="sucursal-principal-option"
                                    style="display: none;"
                                    <?php if(old('sucursal_principal')==$sucursal->id): echo 'selected'; endif; ?>>
                                <?php echo e($sucursal->nombre); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['sucursal_principal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-star"></i> Sucursal por defecto al iniciar sesión
                        </small>
                    </div>
                </div>

            </div>
            <div class="card-footer text-center">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Guardar Usuario
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.sucursal-check');
    const selectPrincipal = document.getElementById('sucursal_principal');
    const options = selectPrincipal.querySelectorAll('.sucursal-principal-option');

    // Función para actualizar opciones de sucursal principal
    function actualizarSucursalPrincipal() {
        // Ocultar todas las opciones primero
        options.forEach(option => {
            option.style.display = 'none';
        });

        // Mostrar solo las opciones de sucursales seleccionadas
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const sucursalId = checkbox.value;
                const option = selectPrincipal.querySelector(`option[value="${sucursalId}"]`);
                if (option) {
                    option.style.display = 'block';
                }
            }
        });

        // Si no hay ninguna seleccionada, resetear select
        const hasChecked = Array.from(checkboxes).some(cb => cb.checked);
        if (!hasChecked) {
            selectPrincipal.value = '';
        }
    }

    // Agregar evento a cada checkbox
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', actualizarSucursalPrincipal);
    });

    // Ejecutar al cargar
    actualizarSucursalPrincipal();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/user/create.blade.php ENDPATH**/ ?>