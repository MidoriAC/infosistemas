<?php $__env->startSection('title','Crear Ubicación'); ?>

<?php $__env->startPush('css'); ?>
<style>
    .required:after {
        content: " *";
        color: red;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4 text-center">Crear Ubicación</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('ubicaciones.index')); ?>">Ubicaciones</a></li>
        <li class="breadcrumb-item active">Crear Ubicación</li>
    </ol>

    <div class="card">
        <form action="<?php echo e(route('ubicaciones.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-header bg-primary text-white">
                <i class="fas fa-map-marker-alt me-2"></i>
                <strong>Formulario de Registro</strong>
            </div>
            <div class="card-body">

                
                <div class="mb-4">
                    <h5 class="border-bottom pb-2">
                        <i class="fas fa-info-circle me-2"></i>Información Básica
                    </h5>
                </div>

                <!-- Sucursal -->
                <div class="row mb-4">
                    <label for="sucursal_id" class="col-lg-2 col-form-label required">Sucursal:</label>
                    <div class="col-lg-4">
                        <select name="sucursal_id"
                                id="sucursal_id"
                                class="form-select <?php $__errorArgs = ['sucursal_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="" selected disabled>Seleccione una sucursal</option>
                            <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sucursal->id); ?>"
                                    <?php if(old('sucursal_id')==$sucursal->id): echo 'selected'; endif; ?>>
                                <?php echo e($sucursal->nombre); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['sucursal_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-store"></i> Sucursal a la que pertenece la ubicación
                        </small>
                    </div>
                </div>

                <!-- Código -->
                <div class="row mb-4">
                    <label for="codigo" class="col-lg-2 col-form-label required">Código:</label>
                    <div class="col-lg-4">
                        <input autocomplete="off"
                               type="text"
                               name="codigo"
                               id="codigo"
                               class="form-control text-uppercase <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('codigo')); ?>"
                               placeholder="Ej: A-01, EST-001">
                        <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-barcode"></i> Código único de identificación
                        </small>
                    </div>
                </div>

                <!-- Nombre -->
                <div class="row mb-4">
                    <label for="nombre" class="col-lg-2 col-form-label required">Nombre:</label>
                    <div class="col-lg-4">
                        <input autocomplete="off"
                               type="text"
                               name="nombre"
                               id="nombre"
                               class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('nombre')); ?>"
                               placeholder="Ej: Estante Principal">
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-tag"></i> Nombre descriptivo de la ubicación
                        </small>
                    </div>
                </div>

                
                <div class="mb-4 mt-5">
                    <h5 class="border-bottom pb-2">
                        <i class="fas fa-cogs me-2"></i>Características
                    </h5>
                </div>

                <!-- Tipo -->
                <div class="row mb-4">
                    <label for="tipo" class="col-lg-2 col-form-label required">Tipo:</label>
                    <div class="col-lg-4">
                        <select name="tipo"
                                id="tipo"
                                class="form-select <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="" selected disabled>Seleccione un tipo</option>
                            <option value="estante" <?php if(old('tipo')=='estante'): echo 'selected'; endif; ?>>Estante</option>
                            <option value="pasillo" <?php if(old('tipo')=='pasillo'): echo 'selected'; endif; ?>>Pasillo</option>
                            <option value="zona" <?php if(old('tipo')=='zona'): echo 'selected'; endif; ?>>Zona</option>
                            <option value="bodega" <?php if(old('tipo')=='bodega'): echo 'selected'; endif; ?>>Bodega</option>
                            <option value="mostrador" <?php if(old('tipo')=='mostrador'): echo 'selected'; endif; ?>>Mostrador</option>
                            <option value="deposito" <?php if(old('tipo')=='deposito'): echo 'selected'; endif; ?>>Depósito</option>
                        </select>
                        <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-layer-group"></i> Tipo de ubicación física
                        </small>
                    </div>
                </div>

                <!-- Sección -->
                <div class="row mb-4">
                    <label for="seccion" class="col-lg-2 col-form-label">Sección:</label>
                    <div class="col-lg-4">
                        <input autocomplete="off"
                               type="text"
                               name="seccion"
                               id="seccion"
                               class="form-control <?php $__errorArgs = ['seccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('seccion')); ?>"
                               placeholder="Ej: Norte, Sur, Piso 2">
                        <?php $__errorArgs = ['seccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-map-signs"></i> Sección o área donde se encuentra (opcional)
                        </small>
                    </div>
                </div>

                <!-- Capacidad Máxima -->
                <div class="row mb-4">
                    <label for="capacidad_maxima" class="col-lg-2 col-form-label">Capacidad Máxima:</label>
                    <div class="col-lg-4">
                        <input autocomplete="off"
                               type="number"
                               name="capacidad_maxima"
                               id="capacidad_maxima"
                               class="form-control <?php $__errorArgs = ['capacidad_maxima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('capacidad_maxima')); ?>"
                               min="0"
                               placeholder="Ej: 100">
                        <?php $__errorArgs = ['capacidad_maxima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-6">
                        <small class="form-text text-muted">
                            <i class="fas fa-boxes"></i> Cantidad máxima de productos (opcional)
                        </small>
                    </div>
                </div>

                <!-- Descripción -->
                <div class="row mb-4">
                    <label for="descripcion" class="col-lg-2 col-form-label">Descripción:</label>
                    <div class="col-lg-8">
                        <textarea name="descripcion"
                                  id="descripcion"
                                  rows="3"
                                  class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  placeholder="Descripción adicional de la ubicación (opcional)"><?php echo e(old('descripcion')); ?></textarea>
                        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

            </div>
            <div class="card-footer text-center">
                <a href="<?php echo e(route('ubicaciones.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Guardar Ubicación
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Convertir código a mayúsculas automáticamente
    const codigoInput = document.getElementById('codigo');
    codigoInput.addEventListener('input', function() {
        this.value = this.value.toUpperCase();
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u945002378/domains/demo-pos.xyz/public_html/pos-multi-branch/resources/views/ubicacion/create.blade.php ENDPATH**/ ?>